import { Stack, useRouter } from 'expo-router'
import { useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'

export default function AuthLayout() { const { isAuthenticated, role } = useAuth(); const router = useRouter(); useEffect(() => { if (isAuthenticated) router.replace(role === 'EMPLOYEE' ? '/(employee)/(tabs)' : '/(hr)/(tabs)') }, [isAuthenticated, role, router]); return <Stack screenOptions={{ headerShown: false }} /> }
