import { zodResolver } from '@hookform/resolvers/zod'
import { Controller, useForm } from 'react-hook-form'
import { StyleSheet, Text } from 'react-native'
import { Link, useRouter } from 'expo-router'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Screen } from '@/components/ui/Screen'
import { colors } from '@/theme/colors'
import { forgotPasswordSchema } from '@/validation/auth.schema'

export default function ForgotPassword() { const router = useRouter(); const { control, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(forgotPasswordSchema), defaultValues: { email: '' } }); return <Screen><Text style={styles.title}>Reset your password</Text><Text style={styles.subtitle}>Enter your work email and we will send a reset link.</Text><Card style={styles.card}><Controller control={control} name="email" render={({ field: { onChange, value } }) => <Input label="Work email" placeholder="you@company.com" autoCapitalize="none" keyboardType="email-address" value={value} onChangeText={onChange} error={errors.email?.message as string} />} /><Button label="Send reset link" onPress={handleSubmit(() => router.replace({ pathname: '/(auth)/verify-email', params: { mode: 'reset' } }))} /></Card><Link href="/(auth)/login" style={styles.back}>Back to sign in</Link></Screen> }
const styles = StyleSheet.create({ title: { color: colors.ink, fontSize: 30, fontWeight: '800', marginTop: 55 }, subtitle: { color: colors.muted, fontSize: 14, lineHeight: 21, marginTop: 7 }, card: { marginTop: 26, gap: 16 }, back: { color: colors.primary, textAlign: 'center', marginTop: 8, fontWeight: '800' } })
