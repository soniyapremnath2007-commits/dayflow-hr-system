import { zodResolver } from '@hookform/resolvers/zod'
import { Eye, EyeOff, LockKeyhole, Mail } from '@/components/ui/icons'
import { useState } from 'react'
import { Controller, useForm } from 'react-hook-form'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { Link, useRouter } from 'expo-router'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Screen } from '@/components/ui/Screen'
import { demoPassword } from '@/data/mockUsers'
import { useAuth } from '@/hooks/useAuth'
import { colors } from '@/theme/colors'
import { loginSchema, type LoginFormValues } from '@/validation/auth.schema'

export default function Login() {
  const router = useRouter()
  const { login, loading, error, clearError } = useAuth()
  const [showPassword, setShowPassword] = useState(false)
  const { control, handleSubmit, setValue, formState: { errors } } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: demoPassword },
  })

  const goToHome = (role: string) => router.replace(role === 'EMPLOYEE' ? '/(employee)/(tabs)' : '/(hr)/(tabs)')
  const submit = async (values: LoginFormValues) => {
    const user = await login(values)
    if (user) goToHome(user.role)
  }
  const quickLogin = async (email: string) => {
    setValue('email', email)
    setValue('password', demoPassword)
    const user = await login({ email, password: demoPassword })
    if (user) goToHome(user.role)
  }

  return <Screen>
    <View style={styles.header}><View style={styles.logo}><Text style={styles.logoText}>d</Text></View><Text style={styles.brand}>dayflow</Text></View>
    <View style={styles.intro}><Text style={styles.title}>Welcome back</Text><Text style={styles.subtitle}>Sign in to pick up where you left off.</Text></View>
    <Card style={styles.formCard}>
      <Controller control={control} name="email" render={({ field: { onChange, value } }) => <Input label="Work email" placeholder="you@company.com" autoCapitalize="none" keyboardType="email-address" value={value} onChangeText={(nextValue) => { clearError(); onChange(nextValue) }} error={errors.email?.message} />} />
      <Controller control={control} name="password" render={({ field: { onChange, value } }) => <View><Input label="Password" placeholder="Enter password" secureTextEntry={!showPassword} value={value} onChangeText={onChange} error={errors.password?.message} /><Pressable onPress={() => setShowPassword(!showPassword)} style={styles.eye}>{showPassword ? <EyeOff size={18} color={colors.muted} /> : <Eye size={18} color={colors.muted} />}</Pressable></View>} />
      {error && <Text style={styles.error}>{error}</Text>}
      <Link href="/(auth)/forgot-password" style={styles.forgot}>Forgot password?</Link>
      <Button label="Sign in" onPress={handleSubmit(submit)} loading={loading} icon={<LockKeyhole size={17} color={colors.white} />} />
      <View style={styles.or}><View style={styles.rule} /><Text style={styles.orText}>DEMO ACCESS</Text><View style={styles.rule} /></View>
      <View style={styles.demoRow}><Pressable onPress={() => quickLogin('employee@dayflow.demo')} style={styles.demoButton}><Mail size={15} color={colors.primary} /><Text style={styles.demoText}>Employee</Text></Pressable><Pressable onPress={() => quickLogin('hr@dayflow.demo')} style={styles.demoButton}><Mail size={15} color={colors.primary} /><Text style={styles.demoText}>HR / Admin</Text></Pressable></View>
      <Text style={styles.demoHint}>Demo password: <Text style={styles.demoStrong}>{demoPassword}</Text></Text>
    </Card>
    <Text style={styles.footer}>Need an account? <Link href="/(auth)/register" style={styles.link}>Request access</Link></Text>
  </Screen>
}

const styles = StyleSheet.create({ header: { flexDirection: 'row', alignItems: 'center', gap: 9, marginTop: 8 }, logo: { width: 35, height: 35, borderRadius: 12, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' }, logoText: { color: colors.white, fontSize: 23, fontWeight: '900' }, brand: { color: colors.ink, fontSize: 20, fontWeight: '800' }, intro: { marginTop: 42, gap: 6 }, title: { color: colors.ink, fontSize: 31, fontWeight: '800', letterSpacing: -0.6 }, subtitle: { color: colors.muted, fontSize: 14 }, formCard: { marginTop: 25, gap: 16 }, eye: { position: 'absolute', right: 15, top: 34, padding: 8 }, error: { color: colors.error, fontSize: 12, marginTop: -5 }, forgot: { textAlign: 'right', color: colors.primary, fontSize: 12, fontWeight: '700', marginTop: -5 }, or: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 2 }, rule: { height: 1, flex: 1, backgroundColor: colors.border }, orText: { color: colors.muted, fontSize: 9, fontWeight: '800', letterSpacing: 1 }, demoRow: { flexDirection: 'row', gap: 10 }, demoButton: { flex: 1, height: 44, borderRadius: 13, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6 }, demoText: { color: colors.ink, fontSize: 12, fontWeight: '700' }, demoHint: { color: colors.muted, textAlign: 'center', fontSize: 10 }, demoStrong: { color: colors.ink, fontWeight: '800' }, footer: { textAlign: 'center', color: colors.muted, fontSize: 13, marginTop: 3 }, link: { color: colors.primary, fontWeight: '800' } })
