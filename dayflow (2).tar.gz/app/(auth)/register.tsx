import { zodResolver } from '@hookform/resolvers/zod'
import { Controller, useForm } from 'react-hook-form'
import { StyleSheet, Text } from 'react-native'
import { Link, useRouter } from 'expo-router'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Screen } from '@/components/ui/Screen'
import { colors } from '@/theme/colors'
import { registerSchema } from '@/validation/auth.schema'

export default function Register() { const router = useRouter(); const { control, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(registerSchema), defaultValues: { name: '', email: '', employeeId: '', password: '' } }); return <Screen><Text style={styles.title}>Create your account</Text><Text style={styles.subtitle}>Set up your Dayflow workspace access.</Text><Card style={styles.card}><Controller control={control} name="name" render={({ field: { onChange, value } }) => <Input label="Full name" placeholder="Your name" value={value} onChangeText={onChange} error={errors.name?.message as string} />} /><Controller control={control} name="email" render={({ field: { onChange, value } }) => <Input label="Work email" placeholder="you@company.com" value={value} autoCapitalize="none" keyboardType="email-address" onChangeText={onChange} error={errors.email?.message as string} />} /><Controller control={control} name="employeeId" render={({ field: { onChange, value } }) => <Input label="Employee ID" placeholder="DF-0000" value={value} onChangeText={onChange} error={errors.employeeId?.message as string} />} /><Controller control={control} name="password" render={({ field: { onChange, value } }) => <Input label="Password" placeholder="At least 6 characters" secureTextEntry value={value} onChangeText={onChange} error={errors.password?.message as string} />} /><Button label="Create account" onPress={handleSubmit(() => router.replace('/(auth)/verify-email'))} /></Card><Text style={styles.footer}>Already have access? <Link href="/(auth)/login" style={styles.link}>Sign in</Link></Text></Screen> }
const styles = StyleSheet.create({ title: { color: colors.ink, fontSize: 30, fontWeight: '800', marginTop: 35 }, subtitle: { color: colors.muted, fontSize: 14, marginTop: 7 }, card: { marginTop: 26, gap: 16 }, footer: { color: colors.muted, textAlign: 'center', marginTop: 4 }, link: { color: colors.primary, fontWeight: '800' } })
