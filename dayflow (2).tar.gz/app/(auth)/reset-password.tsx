import { zodResolver } from '@hookform/resolvers/zod'
import { Controller, useForm } from 'react-hook-form'
import { StyleSheet, Text } from 'react-native'
import { useRouter } from 'expo-router'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Screen } from '@/components/ui/Screen'
import { colors } from '@/theme/colors'
import { resetPasswordSchema, type ResetPasswordFormValues } from '@/validation/auth.schema'

export default function ResetPassword() { const router = useRouter(); const { control, handleSubmit, formState: { errors } } = useForm<ResetPasswordFormValues>({ resolver: zodResolver(resetPasswordSchema), defaultValues: { password: '', confirmPassword: '' } }); return <Screen><Text style={styles.title}>Choose a new password</Text><Text style={styles.subtitle}>Make it memorable and at least 6 characters.</Text><Card style={styles.card}><Controller control={control} name="password" render={({ field: { onChange, value } }) => <Input label="New password" placeholder="Enter new password" secureTextEntry value={value} onChangeText={onChange} error={errors.password?.message} />} /><Controller control={control} name="confirmPassword" render={({ field: { onChange, value } }) => <Input label="Confirm password" placeholder="Repeat new password" secureTextEntry value={value} onChangeText={onChange} error={errors.confirmPassword?.message} />} /><Button label="Update password" onPress={handleSubmit(() => router.replace('/(auth)/login'))} /></Card></Screen> }
const styles = StyleSheet.create({ title: { color: colors.ink, fontSize: 30, fontWeight: '800', marginTop: 55 }, subtitle: { color: colors.muted, fontSize: 14, marginTop: 7 }, card: { marginTop: 26, gap: 16 } })
