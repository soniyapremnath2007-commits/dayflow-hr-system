import { MailCheck } from '@/components/ui/icons'
import { Alert, StyleSheet, Text, View } from 'react-native'
import { Link, useLocalSearchParams, useRouter } from 'expo-router'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Screen } from '@/components/ui/Screen'
import { colors } from '@/theme/colors'

export default function VerifyEmail() { const router = useRouter(); const { mode } = useLocalSearchParams<{ mode?: string }>(); return <Screen><View style={styles.wrap}><View style={styles.icon}><MailCheck size={34} color={colors.primary} /></View><Text style={styles.title}>Check your inbox</Text><Text style={styles.subtitle}>We sent a secure link to your work email. Open it to continue.</Text><Card style={styles.card}><Text style={styles.hint}>Didn't receive it?</Text><Button label="Resend email" variant="secondary" onPress={() => Alert.alert('Email resent', 'Check your inbox for the latest link.')} /></Card>{mode === 'reset' && <Button label="Continue to reset password" onPress={() => router.replace('/(auth)/reset-password')} />}<Link href="/(auth)/login" style={styles.link}>Back to sign in</Link></View></Screen> }
const styles = StyleSheet.create({ wrap: { alignItems: 'center', paddingTop: 90 }, icon: { width: 76, height: 76, borderRadius: 24, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, title: { color: colors.ink, fontSize: 28, fontWeight: '800', marginTop: 22 }, subtitle: { color: colors.muted, fontSize: 14, lineHeight: 21, textAlign: 'center', marginTop: 8, maxWidth: 290 }, card: { width: '100%', marginTop: 28, gap: 12 }, hint: { color: colors.muted, textAlign: 'center', fontSize: 13 }, link: { color: colors.primary, fontWeight: '800', marginTop: 20 } })
