import { Pressable, StyleSheet, Text } from 'react-native'
import { useRouter } from 'expo-router'
import { AttendanceCard } from '@/components/dashboard/AttendanceCard'
import { LeaveSummary } from '@/components/dashboard/LeaveSummary'
import { QuickStats } from '@/components/dashboard/QuickStats'
import { RecentActivity } from '@/components/dashboard/RecentActivity'
import { UpcomingEvents } from '@/components/dashboard/UpcomingEvents'
import { WeeklyAttendanceChart } from '@/components/dashboard/WeeklyAttendanceChart'
import { Screen } from '@/components/ui/Screen'
import { WelcomeHeader } from '@/components/dashboard/WelcomeHeader'
import { useAttendance } from '@/hooks/useAttendance'
import { useAuth } from '@/hooks/useAuth'
import { useEmployeeStore } from '@/store/employeeStore'
import { useLeave } from '@/hooks/useLeave'
import { todayKey } from '@/utils/date'
import { colors } from '@/theme/colors'

export default function EmployeeDashboard() { const router = useRouter(); const { user } = useAuth(); const employee = useEmployeeStore((state) => state.employees.find((item) => item.employeeId === user?.employeeId)); const attendance = useAttendance(employee?.id); const leave = useLeave(employee?.id); const today = attendance.records.find((record) => record.date === todayKey()); return <Screen><WelcomeHeader user={user!} onNotifications={() => router.push('/(employee)/notifications')} /><AttendanceCard record={today} onCheckIn={() => attendance.checkIn(employee?.id ?? 'e-001')} onCheckOut={() => attendance.checkOut(employee?.id ?? 'e-001')} /><QuickStats /><WeeklyAttendanceChart /><LeaveSummary balances={leave.balances} onPress={() => router.push('/(employee)/(tabs)/leave')} /><RecentActivity /><UpcomingEvents /><Pressable onPress={() => router.push('/(employee)/settings')}><Text style={styles.settings}>Manage preferences in Settings</Text></Pressable></Screen> }
const styles = StyleSheet.create({ settings: { color: colors.primary, textAlign: 'center', fontSize: 12, fontWeight: '700', paddingBottom: 12 } })
