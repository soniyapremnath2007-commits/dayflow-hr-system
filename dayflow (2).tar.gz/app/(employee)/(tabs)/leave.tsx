import { ArrowRight, Plus } from '@/components/ui/icons'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { useRouter } from 'expo-router'
import { LeaveBalanceCard } from '@/components/leave/LeaveBalanceCard'
import { LeaveRequestCard } from '@/components/leave/LeaveRequestCard'
import { Header } from '@/components/navigation/Header'
import { Button } from '@/components/ui/Button'
import { Screen } from '@/components/ui/Screen'
import { useAuth } from '@/hooks/useAuth'
import { useLeave } from '@/hooks/useLeave'
import { useEmployeeStore } from '@/store/employeeStore'
import { colors } from '@/theme/colors'

export default function EmployeeLeave() { const router = useRouter(); const { user } = useAuth(); const employee = useEmployeeStore((state) => state.employees.find((item) => item.employeeId === user?.employeeId)); const leave = useLeave(employee?.id); return <Screen><Header title="Leave" subtitle="Take time that works for you" onNotification={() => router.push('/(employee)/notifications')} /><LeaveBalanceCard balances={leave.balances} /><Button label="Apply for leave" onPress={() => router.push('/(employee)/leave/apply')} icon={<Plus size={17} color={colors.white} />} /><View style={styles.section}><View style={styles.sectionHeader}><Text style={styles.title}>Recent requests</Text><Pressable onPress={() => router.push('/(employee)/leave/history')} style={styles.viewAll}><Text style={styles.viewText}>View history</Text><ArrowRight size={14} color={colors.primary} /></Pressable></View>{leave.requests.slice(0, 3).map((request) => <LeaveRequestCard key={request.id} request={request} onPress={() => router.push({ pathname: '/(employee)/leave/details', params: { id: request.id } })} />)}</View></Screen> }
const styles = StyleSheet.create({ section: { gap: 10 }, sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, title: { color: colors.ink, fontSize: 16, fontWeight: '800' }, viewAll: { flexDirection: 'row', gap: 4, alignItems: 'center' }, viewText: { color: colors.primary, fontSize: 12, fontWeight: '700' } })
