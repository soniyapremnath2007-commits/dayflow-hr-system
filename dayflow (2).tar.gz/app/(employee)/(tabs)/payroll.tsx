import { ArrowRight, History } from '@/components/ui/icons'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { useRouter } from 'expo-router'
import { Header } from '@/components/navigation/Header'
import { SalaryHistoryCard } from '@/components/payroll/SalaryHistoryCard'
import { SalarySummaryCard } from '@/components/payroll/SalarySummaryCard'
import { Card } from '@/components/ui/Card'
import { Screen } from '@/components/ui/Screen'
import { useAuth } from '@/hooks/useAuth'
import { usePayroll } from '@/hooks/usePayroll'
import { useEmployeeStore } from '@/store/employeeStore'
import { colors } from '@/theme/colors'

export default function EmployeePayroll() { const router = useRouter(); const { user } = useAuth(); const employee = useEmployeeStore((state) => state.employees.find((item) => item.employeeId === user?.employeeId)); const payroll = usePayroll(employee?.id); return <Screen><Header title="Payroll" subtitle="A clear view of your earnings" onNotification={() => router.push('/(employee)/notifications')} /><SalarySummaryCard payroll={payroll.payroll[0]} onPress={() => router.push('/(employee)/payroll/salary-slip')} /><Card padded={false}><Pressable style={styles.linkRow} onPress={() => router.push('/(employee)/payroll/salary-slip')}><View style={styles.icon}><History size={18} color={colors.primary} /></View><View style={styles.copy}><Text style={styles.title}>View August salary slip</Text><Text style={styles.subtitle}>Your complete earnings statement</Text></View><ArrowRight size={17} color={colors.muted} /></Pressable></Card><View style={styles.section}><Text style={styles.heading}>Salary history</Text>{payroll.payroll.map((item) => <SalaryHistoryCard key={item.id} item={item} onPress={() => router.push('/(employee)/payroll/salary-slip')} />)}</View></Screen> }
const styles = StyleSheet.create({ linkRow: { flexDirection: 'row', alignItems: 'center', gap: 11, padding: 15 }, icon: { width: 38, height: 38, borderRadius: 12, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, copy: { flex: 1 }, title: { color: colors.ink, fontSize: 13, fontWeight: '800' }, subtitle: { color: colors.muted, fontSize: 11, marginTop: 3 }, section: { gap: 10 }, heading: { color: colors.ink, fontSize: 16, fontWeight: '800' } })
