import { ChevronRight, FileText, Pencil, Settings2 } from '@/components/ui/icons'
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native'
import { useRouter } from 'expo-router'
import { EmployeeHeader } from '@/components/employees/EmployeeHeader'
import { Header } from '@/components/navigation/Header'
import { Card } from '@/components/ui/Card'
import { Screen } from '@/components/ui/Screen'
import { useAuth } from '@/hooks/useAuth'
import { useEmployeeStore } from '@/store/employeeStore'
import { colors } from '@/theme/colors'

export default function EmployeeProfile() { const router = useRouter(); const { user } = useAuth(); const employee = useEmployeeStore((state) => state.employees.find((item) => item.employeeId === user?.employeeId)); if (!employee) return null; return <Screen><Header title="Profile" subtitle="Your Dayflow identity" /><EmployeeHeader employee={employee} /><Card padded={false}><Pressable style={styles.row} onPress={() => router.push('/(employee)/settings')}><View style={styles.icon}><Pencil size={17} color={colors.primary} /></View><Text style={styles.label}>Edit personal information</Text><ChevronRight size={16} color={colors.muted} /></Pressable><Pressable style={styles.row} onPress={() => Alert.alert('My documents', 'Documents are managed by your People Operations team.')}><View style={[styles.icon, { backgroundColor: colors.warningSoft }]}><FileText size={17} color={colors.warning} /></View><Text style={styles.label}>My documents</Text><ChevronRight size={16} color={colors.muted} /></Pressable><Pressable style={styles.row} onPress={() => router.push('/(employee)/settings')}><View style={[styles.icon, { backgroundColor: colors.successSoft }]}><Settings2 size={17} color={colors.success} /></View><Text style={styles.label}>Account settings</Text><ChevronRight size={16} color={colors.muted} /></Pressable></Card></Screen> }
const styles = StyleSheet.create({ row: { minHeight: 64, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 15, borderBottomWidth: 1, borderBottomColor: colors.border }, icon: { width: 36, height: 36, borderRadius: 11, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, label: { flex: 1, color: colors.ink, fontSize: 13, fontWeight: '700' } })
