import { Stack, useRouter } from 'expo-router'
import { useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { canAccessHR } from '@/utils/permissions'

export default function EmployeeLayout() { const { isAuthenticated, role } = useAuth(); const router = useRouter(); useEffect(() => { if (!isAuthenticated) router.replace('/(auth)/login'); else if (canAccessHR(role)) router.replace('/(hr)/(tabs)') }, [isAuthenticated, role, router]); return <Stack screenOptions={{ headerShown: false }} /> }
