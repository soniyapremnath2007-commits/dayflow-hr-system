import { Header } from '@/components/navigation/Header'
import { AttendanceCalendar } from '@/components/attendance/AttendanceCalendar'
import { Screen } from '@/components/ui/Screen'
import { useAuth } from '@/hooks/useAuth'
import { useAttendance } from '@/hooks/useAttendance'
import { useEmployeeStore } from '@/store/employeeStore'

export default function AttendanceCalendarScreen() { const { user } = useAuth(); const employee = useEmployeeStore((state) => state.employees.find((item) => item.employeeId === user?.employeeId)); const attendance = useAttendance(employee?.id); return <Screen><Header title="Attendance calendar" subtitle="August 2026" back /><AttendanceCalendar records={attendance.records} /></Screen> }
