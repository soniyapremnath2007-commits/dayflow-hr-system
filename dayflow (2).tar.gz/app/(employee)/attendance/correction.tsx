import { zodResolver } from '@hookform/resolvers/zod'
import { Controller, useForm } from 'react-hook-form'
import { StyleSheet, Text } from 'react-native'
import { useRouter } from 'expo-router'
import { Header } from '@/components/navigation/Header'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Screen } from '@/components/ui/Screen'
import { Toast } from '@/components/ui/Toast'
import { useState } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { useAttendanceStore } from '@/store/attendanceStore'
import { useEmployeeStore } from '@/store/employeeStore'
import { colors } from '@/theme/colors'
import { attendanceCorrectionSchema } from '@/validation/attendance.schema'

export default function AttendanceCorrection() { const router = useRouter(); const { user } = useAuth(); const employee = useEmployeeStore((state) => state.employees.find((item) => item.employeeId === user?.employeeId)); const requestCorrection = useAttendanceStore((state) => state.requestCorrection); const [sent, setSent] = useState(false); const { control, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(attendanceCorrectionSchema), defaultValues: { date: '', checkIn: '', checkOut: '', reason: '' } }); const submit = (values: { date: string; checkIn: string; checkOut: string; reason: string }) => { requestCorrection({ id: `cor-${Date.now()}`, attendanceId: '', employeeId: employee?.id ?? '', date: values.date, requestedCheckIn: values.checkIn, requestedCheckOut: values.checkOut, reason: values.reason, status: 'Pending' }); setSent(true); setTimeout(() => router.back(), 800) }; return <Screen><Header title="Request correction" subtitle="Make a missed punch right" back /><Card style={styles.card}>{sent ? <Toast message="Correction request sent to HR" /> : <><Text style={styles.intro}>Tell us what needs updating and the HR team will review it.</Text><Controller control={control} name="date" render={({ field: { onChange, value } }) => <Input label="Date" placeholder="YYYY-MM-DD" value={value} onChangeText={onChange} error={errors.date?.message as string} />} /><Controller control={control} name="checkIn" render={({ field: { onChange, value } }) => <Input label="Correct check-in" placeholder="09:00" value={value} onChangeText={onChange} error={errors.checkIn?.message as string} />} /><Controller control={control} name="checkOut" render={({ field: { onChange, value } }) => <Input label="Correct check-out" placeholder="18:00" value={value} onChangeText={onChange} error={errors.checkOut?.message as string} />} /><Controller control={control} name="reason" render={({ field: { onChange, value } }) => <Input label="Reason" placeholder="What happened?" value={value} onChangeText={onChange} multiline style={styles.reason} error={errors.reason?.message as string} />} /><Button label="Send to HR" onPress={handleSubmit(submit)} /></>}</Card></Screen> }
const styles = StyleSheet.create({ card: { gap: 16 }, intro: { color: colors.muted, lineHeight: 19, fontSize: 13 }, reason: { minHeight: 84, paddingTop: 14 } })
