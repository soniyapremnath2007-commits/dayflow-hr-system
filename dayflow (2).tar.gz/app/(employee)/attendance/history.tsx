import { Header } from '@/components/navigation/Header'
import { AttendanceHistoryCard } from '@/components/attendance/AttendanceHistoryCard'
import { Screen } from '@/components/ui/Screen'
import { useAuth } from '@/hooks/useAuth'
import { useAttendance } from '@/hooks/useAttendance'
import { useEmployeeStore } from '@/store/employeeStore'

export default function AttendanceHistory() { const { user } = useAuth(); const employee = useEmployeeStore((state) => state.employees.find((item) => item.employeeId === user?.employeeId)); const attendance = useAttendance(employee?.id); return <Screen><Header title="Attendance history" subtitle="Your working days at a glance" back />{attendance.records.map((record) => <AttendanceHistoryCard key={record.id} record={record} />)}</Screen> }
