import { StyleSheet, Text } from 'react-native'
import { useRouter } from 'expo-router'
import { Header } from '@/components/navigation/Header'
import { LeaveForm } from '@/components/leave/LeaveForm'
import { Card } from '@/components/ui/Card'
import { Screen } from '@/components/ui/Screen'
import { useAuth } from '@/hooks/useAuth'
import { useEmployeeStore } from '@/store/employeeStore'
import { useLeaveStore } from '@/store/leaveStore'
import { calculateLeaveDuration } from '@/utils/leave'
import { colors } from '@/theme/colors'

export default function ApplyLeave() { const router = useRouter(); const { user } = useAuth(); const employee = useEmployeeStore((state) => state.employees.find((item) => item.employeeId === user?.employeeId)); const applyLeave = useLeaveStore((state) => state.applyLeave); return <Screen><Header title="Apply for leave" subtitle="A little space can go a long way" back /><Card><Text style={styles.intro}>Choose your dates and add context for your manager.</Text><LeaveForm onSubmit={(values) => { applyLeave({ id: `leave-${Date.now()}`, employeeId: employee?.id ?? 'e-001', employeeName: employee?.name ?? 'Employee Demo', type: values.type, startDate: values.startDate, endDate: values.endDate, days: calculateLeaveDuration(values.startDate, values.endDate), reason: values.reason, status: 'Pending', createdAt: new Date().toISOString().slice(0, 10) }); router.replace('/(employee)/(tabs)/leave') }} /></Card></Screen> }
const styles = StyleSheet.create({ intro: { color: colors.muted, fontSize: 13, lineHeight: 19, marginBottom: 16 } })
