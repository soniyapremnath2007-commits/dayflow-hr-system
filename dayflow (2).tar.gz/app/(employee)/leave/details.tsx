import { StyleSheet, Text, View } from 'react-native'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Header } from '@/components/navigation/Header'
import { LeaveStatusBadge } from '@/components/leave/LeaveStatusBadge'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Screen } from '@/components/ui/Screen'
import { useLeaveStore } from '@/store/leaveStore'
import { formatDate } from '@/utils/date'
import { colors } from '@/theme/colors'

export default function LeaveDetails() { const router = useRouter(); const { id } = useLocalSearchParams<{ id: string }>(); const request = useLeaveStore((state) => state.requests.find((item) => item.id === id)); const updateStatus = useLeaveStore((state) => state.updateStatus); if (!request) return <Screen><Header title="Leave request" back /><Text>Request not found.</Text></Screen>; return <Screen><Header title="Leave request" subtitle="Request details" back /><Card style={styles.card}><View style={styles.top}><Text style={styles.type}>{request.type} leave</Text><LeaveStatusBadge status={request.status} /></View><View style={styles.row}><Text style={styles.label}>Dates</Text><Text style={styles.value}>{formatDate(request.startDate)} - {formatDate(request.endDate)}</Text></View><View style={styles.row}><Text style={styles.label}>Duration</Text><Text style={styles.value}>{request.days} {request.days === 1 ? 'day' : 'days'}</Text></View><View style={styles.reason}><Text style={styles.label}>Reason</Text><Text style={styles.value}>{request.reason}</Text></View>{request.status === 'Pending' && <Button label="Cancel request" variant="danger" onPress={() => { updateStatus(request.id, 'Cancelled'); router.back() }} />}</Card></Screen> }
const styles = StyleSheet.create({ card: { gap: 20 }, top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, type: { color: colors.ink, fontSize: 18, fontWeight: '800' }, row: { flexDirection: 'row', justifyContent: 'space-between', gap: 15 }, label: { color: colors.muted, fontSize: 13 }, value: { flex: 1, color: colors.ink, fontSize: 13, fontWeight: '700', textAlign: 'right' }, reason: { gap: 8 } })
