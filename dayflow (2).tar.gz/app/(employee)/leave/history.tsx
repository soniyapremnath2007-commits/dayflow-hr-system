import { Header } from '@/components/navigation/Header'
import { LeaveRequestCard } from '@/components/leave/LeaveRequestCard'
import { Screen } from '@/components/ui/Screen'
import { useAuth } from '@/hooks/useAuth'
import { useLeave } from '@/hooks/useLeave'
import { useEmployeeStore } from '@/store/employeeStore'
import { useRouter } from 'expo-router'

export default function LeaveHistory() { const router = useRouter(); const { user } = useAuth(); const employee = useEmployeeStore((state) => state.employees.find((item) => item.employeeId === user?.employeeId)); const leave = useLeave(employee?.id); return <Screen><Header title="Leave history" subtitle="Every request, in one place" back />{leave.requests.map((request) => <LeaveRequestCard key={request.id} request={request} onPress={() => router.push({ pathname: '/(employee)/leave/details', params: { id: request.id } })} />)}</Screen> }
