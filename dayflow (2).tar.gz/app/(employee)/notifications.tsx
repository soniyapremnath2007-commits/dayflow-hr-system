import { Pressable, StyleSheet, Text, View } from 'react-native'
import { Header } from '@/components/navigation/Header'
import { NotificationCard } from '@/components/notifications/NotificationCard'
import { Screen } from '@/components/ui/Screen'
import { useNotifications } from '@/hooks/useNotifications'
import { colors } from '@/theme/colors'

export default function EmployeeNotifications() { const { notifications, markRead, markAllRead, unreadCount } = useNotifications(); return <Screen><Header title="Notifications" subtitle="Stay close to what matters" back /><View style={styles.header}><Text style={styles.count}>{unreadCount ? `${unreadCount} unread` : 'All caught up'}</Text>{unreadCount > 0 && <Pressable onPress={markAllRead}><Text style={styles.mark}>Mark all read</Text></Pressable>}</View>{notifications.map((notification) => <NotificationCard key={notification.id} notification={notification} onPress={() => markRead(notification.id)} />)}</Screen> }
const styles = StyleSheet.create({ header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, count: { color: colors.ink, fontSize: 14, fontWeight: '800' }, mark: { color: colors.primary, fontSize: 12, fontWeight: '700' } })
