import { Header } from '@/components/navigation/Header'
import { SalaryHistoryCard } from '@/components/payroll/SalaryHistoryCard'
import { Screen } from '@/components/ui/Screen'
import { usePayroll } from '@/hooks/usePayroll'
import { useAuth } from '@/hooks/useAuth'
import { useEmployeeStore } from '@/store/employeeStore'

export default function SalaryHistory() { const { user } = useAuth(); const employee = useEmployeeStore((state) => state.employees.find((item) => item.employeeId === user?.employeeId)); const payroll = usePayroll(employee?.id); return <Screen><Header title="Salary history" subtitle="Your earnings over time" back />{payroll.payroll.map((item) => <SalaryHistoryCard key={item.id} item={item} />)}</Screen> }
