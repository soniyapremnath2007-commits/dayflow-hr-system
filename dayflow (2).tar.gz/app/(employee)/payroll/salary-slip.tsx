import { Header } from '@/components/navigation/Header'
import { SalaryBreakdown } from '@/components/payroll/SalaryBreakdown'
import { SalarySlip } from '@/components/payroll/SalarySlip'
import { Screen } from '@/components/ui/Screen'
import { usePayroll } from '@/hooks/usePayroll'
import { useAuth } from '@/hooks/useAuth'
import { useEmployeeStore } from '@/store/employeeStore'

export default function EmployeeSalarySlip() { const { user } = useAuth(); const employee = useEmployeeStore((state) => state.employees.find((item) => item.employeeId === user?.employeeId)); const payroll = usePayroll(employee?.id); return <Screen><Header title="Salary slip" subtitle="August 2026" back /><SalarySlip slip={payroll.salarySlip} /><SalaryBreakdown slip={payroll.salarySlip} /></Screen> }
