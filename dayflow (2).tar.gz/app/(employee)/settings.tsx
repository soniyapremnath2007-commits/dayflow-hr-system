import { ChevronRight, KeyRound, LockKeyhole, Moon, ShieldCheck, UserRound } from '@/components/ui/icons'
import type { ReactNode } from 'react'
import { useState } from 'react'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { useRouter } from 'expo-router'
import { Header } from '@/components/navigation/Header'
import { Toggle } from '@/components/ui/Toggle'
import { Screen } from '@/components/ui/Screen'
import { useAuth } from '@/hooks/useAuth'
import { colors } from '@/theme/colors'

export default function EmployeeSettings() { const router = useRouter(); const logout = useAuth().logout; const [darkMode, setDarkMode] = useState(false); const [notifications, setNotifications] = useState(true); return <Screen><Header title="Settings" subtitle="Make Dayflow yours" back /><View style={styles.group}><Text style={styles.groupTitle}>ACCOUNT</Text><SettingRow icon={UserRound} label="Personal information" /><SettingRow icon={KeyRound} label="Password" /><SettingRow icon={ShieldCheck} label="Security" /></View><View style={styles.group}><Text style={styles.groupTitle}>PREFERENCES</Text><SettingRow icon={Moon} label="Appearance" trailing={<Toggle value={darkMode} onChange={setDarkMode} />} /><SettingRow icon={LockKeyhole} label="Notifications" trailing={<Toggle value={notifications} onChange={setNotifications} />} /></View><Pressable onPress={() => { logout(); router.replace('/(auth)/login') }} style={styles.logout}><Text style={styles.logoutText}>Sign out</Text></Pressable></Screen> }
function SettingRow({ icon: Icon, label, trailing }: { icon: typeof UserRound; label: string; trailing?: ReactNode }) { return <View style={styles.row}><View style={styles.icon}><Icon size={17} color={colors.primary} /></View><Text style={styles.label}>{label}</Text>{trailing ?? <ChevronRight size={16} color={colors.muted} />}</View> }
const styles = StyleSheet.create({ group: { gap: 8 }, groupTitle: { color: colors.muted, fontSize: 10, fontWeight: '800', letterSpacing: 1.4, marginBottom: 3 }, row: { minHeight: 58, paddingHorizontal: 13, backgroundColor: colors.surface, borderRadius: 15, borderWidth: 1, borderColor: colors.border, flexDirection: 'row', alignItems: 'center', gap: 11 }, icon: { width: 32, height: 32, borderRadius: 10, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, label: { flex: 1, color: colors.ink, fontSize: 13, fontWeight: '700' }, logout: { alignItems: 'center', padding: 15 }, logoutText: { color: colors.error, fontSize: 13, fontWeight: '800' } })
