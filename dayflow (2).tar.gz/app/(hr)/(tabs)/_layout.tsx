import { CalendarCheck2, CalendarDays, House, MoreHorizontal, UsersRound } from '@/components/ui/icons'
import { Tabs } from 'expo-router'
import { colors } from '@/theme/colors'

export default function HRTabsLayout() { const tabs = [['index', 'Home', House], ['employees', 'Employees', UsersRound], ['attendance', 'Attendance', CalendarCheck2], ['leave', 'Leave', CalendarDays], ['more', 'More', MoreHorizontal]] as const; return <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: colors.primary, tabBarInactiveTintColor: colors.muted, tabBarLabelStyle: { fontSize: 10, fontWeight: '700' }, tabBarStyle: { height: 72, paddingTop: 8, borderTopColor: colors.border, backgroundColor: colors.surface }, tabBarHideOnKeyboard: true }}>{tabs.map(([name, title, Icon]) => <Tabs.Screen key={name} name={name} options={{ title, tabBarIcon: ({ color, size }) => <Icon color={color} size={size} strokeWidth={2.2} /> }} />)}</Tabs> }
