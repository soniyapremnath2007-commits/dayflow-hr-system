import { Plus } from '@/components/ui/icons'
import { useState } from 'react'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { useRouter } from 'expo-router'
import { EmployeeList } from '@/components/employees/EmployeeList'
import { Header } from '@/components/navigation/Header'
import { SearchBar } from '@/components/ui/SearchBar'
import { Screen } from '@/components/ui/Screen'
import { useEmployees } from '@/hooks/useEmployees'
import { colors } from '@/theme/colors'

export default function HREmployees() { const router = useRouter(); const [search, setSearch] = useState(''); const { employees, selectEmployee } = useEmployees(); const filtered = employees.filter((employee) => `${employee.name} ${employee.department} ${employee.employeeId}`.toLowerCase().includes(search.toLowerCase())); return <Screen><View style={styles.top}><Header title="People" subtitle={`${employees.length} employees in your workspace`} /><Pressable onPress={() => router.push('/(hr)/employees/add')} style={styles.add}><Plus size={19} color={colors.white} /></Pressable></View><SearchBar value={search} onChangeText={setSearch} /><View style={styles.summary}><Text style={styles.summaryText}>All employees</Text><Text style={styles.active}>{filtered.length} shown</Text></View><EmployeeList employees={filtered} onSelect={(employee) => { selectEmployee(employee); router.push({ pathname: '/(hr)/employees/[id]', params: { id: employee.id } }) }} /></Screen> }
const styles = StyleSheet.create({ top: { flexDirection: 'row', alignItems: 'center' }, add: { width: 42, height: 42, borderRadius: 14, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' }, summary: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, summaryText: { color: colors.ink, fontSize: 15, fontWeight: '800' }, active: { color: colors.primary, fontSize: 12, fontWeight: '700' } })
