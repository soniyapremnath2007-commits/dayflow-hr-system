import { Header } from '@/components/navigation/Header'
import { AttendanceHistoryCard } from '@/components/attendance/AttendanceHistoryCard'
import { Screen } from '@/components/ui/Screen'
import { useAttendance } from '@/hooks/useAttendance'
import { useLocalSearchParams } from 'expo-router'

export default function HRAttendanceDetails() { const { employeeId } = useLocalSearchParams<{ employeeId?: string }>(); const attendance = useAttendance(employeeId); return <Screen><Header title="Attendance details" subtitle="Review working time" back />{attendance.records.map((record) => <AttendanceHistoryCard key={record.id} record={record} />)}</Screen> }
