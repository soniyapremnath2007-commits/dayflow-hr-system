import { useRouter } from 'expo-router'
import { Header } from '@/components/navigation/Header'
import { EmployeeForm } from '@/components/employees/EmployeeForm'
import { Card } from '@/components/ui/Card'
import { Screen } from '@/components/ui/Screen'
import { useEmployees } from '@/hooks/useEmployees'
import type { EmployeeFormValues } from '@/validation/employee.schema'

export default function AddEmployee() { const router = useRouter(); const addEmployee = useEmployees().addEmployee; const submit = (values: EmployeeFormValues) => { addEmployee({ id: `e-${Date.now()}`, ...values, phone: '', employmentType: 'Full-time', joiningDate: new Date().toISOString().slice(0, 10), location: 'Bengaluru', status: 'Active', avatarColor: '#3154D8' }); router.back() }; return <Screen><Header title="Add employee" subtitle="Grow your people directory" back /><Card><EmployeeForm onSubmit={submit} /></Card></Screen> }
