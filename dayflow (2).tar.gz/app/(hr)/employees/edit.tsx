import { useLocalSearchParams, useRouter } from 'expo-router'
import { Header } from '@/components/navigation/Header'
import { EmployeeForm } from '@/components/employees/EmployeeForm'
import { Card } from '@/components/ui/Card'
import { Screen } from '@/components/ui/Screen'
import { useEmployees } from '@/hooks/useEmployees'
import type { EmployeeFormValues } from '@/validation/employee.schema'

export default function EditEmployee() { const router = useRouter(); const { id } = useLocalSearchParams<{ id: string }>(); const { employees, updateEmployee } = useEmployees(); const employee = employees.find((item) => item.id === id); if (!employee) return null; return <Screen><Header title="Edit employee" subtitle={employee.name} back /><Card><EmployeeForm initialValues={employee} onSubmit={(values: EmployeeFormValues) => { updateEmployee(employee.id, values); router.back() }} /></Card></Screen> }
