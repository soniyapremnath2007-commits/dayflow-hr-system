import { Check, X } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { useLocalSearchParams, useRouter } from 'expo-router'
import { Header } from '@/components/navigation/Header'
import { LeaveStatusBadge } from '@/components/leave/LeaveStatusBadge'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { Screen } from '@/components/ui/Screen'
import { useLeaveStore } from '@/store/leaveStore'
import { formatDate } from '@/utils/date'
import { colors } from '@/theme/colors'

export default function HRLeaveDetails() { const router = useRouter(); const { id } = useLocalSearchParams<{ id: string }>(); const request = useLeaveStore((state) => state.requests.find((item) => item.id === id)); const updateStatus = useLeaveStore((state) => state.updateStatus); if (!request) return <Screen><Header title="Leave request" back /><Text>Request not found.</Text></Screen>; const decide = (status: 'Approved' | 'Rejected') => { updateStatus(request.id, status); router.back() }; return <Screen><Header title="Request details" subtitle="People Operations review" back /><Card style={styles.card}><View style={styles.top}><View><Text style={styles.name}>{request.employeeName}</Text><Text style={styles.type}>{request.type} leave</Text></View><LeaveStatusBadge status={request.status} /></View><View style={styles.grid}><Info label="Start date" value={formatDate(request.startDate)} /><Info label="End date" value={formatDate(request.endDate)} /><Info label="Duration" value={`${request.days} days`} /><Info label="Submitted" value={formatDate(request.createdAt)} /></View><View style={styles.reason}><Text style={styles.label}>Reason from employee</Text><Text style={styles.reasonText}>{request.reason}</Text></View>{request.status === 'Pending' && <View style={styles.actions}><Button label="Reject" variant="danger" onPress={() => decide('Rejected')} icon={<X size={16} color={colors.error} />} /><View style={styles.grow}><Button label="Approve" onPress={() => decide('Approved')} icon={<Check size={16} color={colors.white} />} /></View></View>}</Card></Screen> }
function Info({ label, value }: { label: string; value: string }) { return <View style={styles.info}><Text style={styles.label}>{label}</Text><Text style={styles.value}>{value}</Text></View> }
const styles = StyleSheet.create({ card: { gap: 20 }, top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, name: { color: colors.ink, fontSize: 18, fontWeight: '800' }, type: { color: colors.muted, fontSize: 12, marginTop: 4 }, grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 16 }, info: { width: '44%', gap: 5 }, label: { color: colors.muted, fontSize: 11, fontWeight: '600' }, value: { color: colors.ink, fontSize: 13, fontWeight: '800' }, reason: { paddingTop: 4, gap: 8 }, reasonText: { color: colors.ink, fontSize: 14, lineHeight: 21 }, actions: { flexDirection: 'row', gap: 10 }, grow: { flex: 1 } })
