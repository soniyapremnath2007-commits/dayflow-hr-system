import { Filter } from '@/components/ui/icons'
import { useState } from 'react'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { useRouter } from 'expo-router'
import { LeaveRequestCard } from '@/components/leave/LeaveRequestCard'
import { Header } from '@/components/navigation/Header'
import { Screen } from '@/components/ui/Screen'
import { useLeave } from '@/hooks/useLeave'
import { colors } from '@/theme/colors'
import type { LeaveStatus } from '@/types/leave.types'

export default function HRLeaveRequests() { const router = useRouter(); const leave = useLeave(); const [filter, setFilter] = useState<LeaveStatus | 'All'>('All'); const filters: (LeaveStatus | 'All')[] = ['All', 'Pending', 'Approved', 'Rejected', 'Cancelled']; const nextFilter = () => setFilter(filters[(filters.indexOf(filter) + 1) % filters.length]); const requests = filter === 'All' ? leave.requests : leave.requests.filter((request) => request.status === filter); return <Screen><Header title="All leave requests" subtitle="Review and make decisions" back /><View style={styles.filters}><Text style={styles.label}>{requests.length} shown</Text><Pressable style={styles.filter} onPress={nextFilter}><Filter size={15} color={colors.primary} /><Text style={styles.filterText}>{filter}</Text></Pressable></View>{requests.map((request) => <LeaveRequestCard key={request.id} request={request} onPress={() => router.push({ pathname: '/(hr)/leave/[id]', params: { id: request.id } })} />)}</Screen> }
const styles = StyleSheet.create({ filters: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, label: { color: colors.ink, fontSize: 14, fontWeight: '800' }, filter: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: colors.primarySoft, borderRadius: 10, paddingVertical: 8, paddingHorizontal: 11 }, filterText: { color: colors.primary, fontSize: 11, fontWeight: '800' } })
