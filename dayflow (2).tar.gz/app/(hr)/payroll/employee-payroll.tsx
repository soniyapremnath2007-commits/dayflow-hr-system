import { Search } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { Header } from '@/components/navigation/Header'
import { SalaryHistoryCard } from '@/components/payroll/SalaryHistoryCard'
import { Input } from '@/components/ui/Input'
import { Screen } from '@/components/ui/Screen'
import { usePayroll } from '@/hooks/usePayroll'
import { useEmployees } from '@/hooks/useEmployees'
import { colors } from '@/theme/colors'
import { useState } from 'react'
import { useRouter } from 'expo-router'

export default function EmployeePayrollList() { const router = useRouter(); const [query, setQuery] = useState(''); const { employees } = useEmployees(); const payroll = usePayroll(); const filtered = payroll.payroll.filter((item) => employees.find((employee) => employee.id === item.employeeId)?.name.toLowerCase().includes(query.toLowerCase())); return <Screen><Header title="Employee payroll" subtitle="Manage individual salaries" back /><Input value={query} onChangeText={setQuery} placeholder="Search by employee" /><View style={styles.heading}><Text style={styles.title}>{filtered.length} payroll records</Text><Search size={17} color={colors.muted} /></View>{filtered.map((item) => <SalaryHistoryCard key={item.id} item={item} onPress={() => router.push({ pathname: '/(hr)/payroll/salary-slip', params: { id: item.id } })} />)}</Screen> }
const styles = StyleSheet.create({ heading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, title: { color: colors.ink, fontSize: 15, fontWeight: '800' } })
