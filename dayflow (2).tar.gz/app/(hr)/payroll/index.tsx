import { ArrowRight, IndianRupee } from '@/components/ui/icons'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { useRouter } from 'expo-router'
import { Header } from '@/components/navigation/Header'
import { KPICard } from '@/components/analytics/KPICard'
import { SalaryHistoryCard } from '@/components/payroll/SalaryHistoryCard'
import { Card } from '@/components/ui/Card'
import { Screen } from '@/components/ui/Screen'
import { usePayroll } from '@/hooks/usePayroll'
import { colors } from '@/theme/colors'
import { formatCurrency } from '@/utils/currency'

export default function HRPayroll() { const router = useRouter(); const payroll = usePayroll(); const current = payroll.payroll.filter((item) => item.month === 'August 2026'); const total = current.reduce((sum, item) => sum + item.net, 0); return <Screen><Header title="Payroll" subtitle="August 2026 cycle" /><View style={styles.grid}><KPICard label="Monthly payout" value={formatCurrency(total)} trend={6} /><KPICard label="Processed" value={`${current.length} people`} trend={2} color={colors.success} /></View><Card style={styles.banner}><View style={styles.icon}><IndianRupee size={20} color={colors.primary} /></View><View style={styles.copy}><Text style={styles.title}>Salary management</Text><Text style={styles.sub}>Review each employee's payroll record.</Text></View><Pressable onPress={() => router.push('/(hr)/payroll/employee-payroll')}><ArrowRight size={18} color={colors.primary} /></Pressable></Card><Text style={styles.heading}>Latest payroll records</Text>{payroll.payroll.map((item) => <SalaryHistoryCard key={item.id} item={item} onPress={() => router.push({ pathname: '/(hr)/payroll/salary-slip', params: { id: item.id } })} />)}</Screen> }
const styles = StyleSheet.create({ grid: { flexDirection: 'row', gap: 10 }, banner: { flexDirection: 'row', alignItems: 'center', gap: 11 }, icon: { width: 42, height: 42, borderRadius: 13, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, copy: { flex: 1 }, title: { color: colors.ink, fontSize: 14, fontWeight: '800' }, sub: { color: colors.muted, fontSize: 11, marginTop: 3 }, heading: { color: colors.ink, fontSize: 16, fontWeight: '800' } })
