import { useLocalSearchParams } from 'expo-router'
import { Header } from '@/components/navigation/Header'
import { SalaryBreakdown } from '@/components/payroll/SalaryBreakdown'
import { SalarySlip } from '@/components/payroll/SalarySlip'
import { Screen } from '@/components/ui/Screen'
import { usePayroll } from '@/hooks/usePayroll'
import { createSalarySlip } from '@/data/mockPayroll'

export default function HRSalarySlip() { const { id } = useLocalSearchParams<{ id?: string }>(); const payroll = usePayroll(); const record = payroll.payroll.find((item) => item.id === id) ?? payroll.payroll[0]; const slip = record ? createSalarySlip(record) : payroll.salarySlip; return <Screen><Header title="Salary slip" subtitle="Payroll record" back /><SalarySlip slip={slip} /><SalaryBreakdown slip={slip} /></Screen> }
