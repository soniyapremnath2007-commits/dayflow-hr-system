import { Header } from '@/components/navigation/Header'
import { AttendanceChart } from '@/components/analytics/AttendanceChart'
import { KPICard } from '@/components/analytics/KPICard'
import { Screen } from '@/components/ui/Screen'
import { colors } from '@/theme/colors'
import { View, StyleSheet } from 'react-native'
export default function AttendanceReport() { return <Screen><Header title="Attendance report" subtitle="August 2026" back /><View style={styles.grid}><KPICard label="Avg. presence" value="91%" trend={4} /><KPICard label="Avg. hours" value="8.4h" trend={2} color={colors.success} /></View><AttendanceChart /></Screen> }
const styles = StyleSheet.create({ grid: { flexDirection: 'row', gap: 10 } })
