import { Header } from '@/components/navigation/Header'
import { KPICard } from '@/components/analytics/KPICard'
import { LeaveChart } from '@/components/analytics/LeaveChart'
import { Screen } from '@/components/ui/Screen'
import { colors } from '@/theme/colors'
import { StyleSheet, View } from 'react-native'
export default function LeaveReport() { return <Screen><Header title="Leave report" subtitle="Quarter to date" back /><View style={styles.grid}><KPICard label="Requests" value="68" trend={12} /><KPICard label="Approval rate" value="86%" trend={3} color={colors.success} /></View><LeaveChart /></Screen> }
const styles = StyleSheet.create({ grid: { flexDirection: 'row', gap: 10 } })
