import { Header } from '@/components/navigation/Header'
import { KPICard } from '@/components/analytics/KPICard'
import { PayrollChart } from '@/components/analytics/PayrollChart'
import { Screen } from '@/components/ui/Screen'
import { colors } from '@/theme/colors'
import { StyleSheet, View } from 'react-native'
export default function PayrollReport() { return <Screen><Header title="Payroll report" subtitle="Payout movement by month" back /><View style={styles.grid}><KPICard label="August payout" value="₹9.8L" trend={6} /><KPICard label="Avg. net pay" value="₹1.22L" trend={4} color={colors.success} /></View><PayrollChart /></Screen> }
const styles = StyleSheet.create({ grid: { flexDirection: 'row', gap: 10 } })
