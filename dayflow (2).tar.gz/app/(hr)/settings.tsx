import { Building2, ChevronRight, KeyRound, ShieldCheck } from '@/components/ui/icons'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { useRouter } from 'expo-router'
import { Header } from '@/components/navigation/Header'
import { Screen } from '@/components/ui/Screen'
import { useAuth } from '@/hooks/useAuth'
import { colors } from '@/theme/colors'
export default function HRSettings() { const router = useRouter(); const logout = useAuth().logout; return <Screen><Header title="Settings" subtitle="Workspace controls" back /><View style={styles.group}><Text style={styles.groupTitle}>WORKSPACE</Text><Row icon={Building2} label="Company profile" /><Row icon={ShieldCheck} label="Permissions & roles" /><Row icon={KeyRound} label="Security" /></View><Pressable onPress={() => { logout(); router.replace('/(auth)/login') }} style={styles.logout}><Text style={styles.logoutText}>Sign out</Text></Pressable></Screen> }
function Row({ icon: Icon, label }: { icon: typeof Building2; label: string }) { return <View style={styles.row}><View style={styles.icon}><Icon size={17} color={colors.primary} /></View><Text style={styles.label}>{label}</Text><ChevronRight size={16} color={colors.muted} /></View> }
const styles = StyleSheet.create({ group: { gap: 8 }, groupTitle: { color: colors.muted, fontSize: 10, fontWeight: '800', letterSpacing: 1.4, marginBottom: 3 }, row: { minHeight: 58, paddingHorizontal: 13, borderRadius: 15, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, flexDirection: 'row', alignItems: 'center', gap: 11 }, icon: { width: 32, height: 32, borderRadius: 10, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, label: { flex: 1, color: colors.ink, fontSize: 13, fontWeight: '700' }, logout: { alignItems: 'center', padding: 16 }, logoutText: { color: colors.error, fontWeight: '800', fontSize: 13 } })
