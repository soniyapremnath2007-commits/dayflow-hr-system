import { Sparkles } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { Header } from '@/components/navigation/Header'
import { Card } from '@/components/ui/Card'
import { Screen } from '@/components/ui/Screen'
import { colors } from '@/theme/colors'
export default function About() { return <Screen><Header title="About Dayflow" subtitle="Your workday, simplified." back /><Card style={styles.card}><View style={styles.icon}><Sparkles size={25} color={colors.primary} /></View><Text style={styles.brand}>dayflow</Text><Text style={styles.version}>Version 1.0.0 · Hackathon demo</Text><Text style={styles.text}>A calmer, clearer way for teams to work together. Built for people who do their best work when the busywork gets out of the way.</Text></Card></Screen> }
const styles = StyleSheet.create({ card: { alignItems: 'center', gap: 9 }, icon: { width: 58, height: 58, borderRadius: 18, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, brand: { color: colors.ink, fontSize: 25, fontWeight: '800' }, version: { color: colors.primary, fontSize: 11, fontWeight: '700' }, text: { color: colors.muted, textAlign: 'center', lineHeight: 20, fontSize: 13, marginTop: 9 } })
