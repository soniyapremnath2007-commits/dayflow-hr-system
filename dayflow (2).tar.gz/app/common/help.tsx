import { MessageCircleQuestion } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { Header } from '@/components/navigation/Header'
import { Card } from '@/components/ui/Card'
import { Screen } from '@/components/ui/Screen'
import { colors } from '@/theme/colors'
export default function Help() { return <Screen><Header title="Help centre" subtitle="We are here to help" back /><Card style={styles.card}><View style={styles.icon}><MessageCircleQuestion size={25} color={colors.primary} /></View><Text style={styles.title}>Need a hand?</Text><Text style={styles.text}>For questions about attendance, leave, or payroll, reach out to your People Operations team.</Text></Card></Screen> }
const styles = StyleSheet.create({ card: { alignItems: 'center', gap: 10 }, icon: { width: 58, height: 58, borderRadius: 18, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, title: { color: colors.ink, fontSize: 18, fontWeight: '800' }, text: { color: colors.muted, textAlign: 'center', lineHeight: 20, fontSize: 13 } })
