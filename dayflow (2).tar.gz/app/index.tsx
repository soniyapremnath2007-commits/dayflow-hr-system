import { Redirect } from 'expo-router'
import { useAuth } from '@/hooks/useAuth'
import { canAccessHR } from '@/utils/permissions'

export default function Index() { const { isAuthenticated, role } = useAuth(); if (!isAuthenticated) return <Redirect href="/(auth)/onboarding" />; return <Redirect href={canAccessHR(role) ? '/(hr)/(tabs)' : '/(employee)/(tabs)'} /> }
