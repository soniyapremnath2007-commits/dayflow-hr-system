# Font assets

Place licensed font files here and register them in the root layout when the final type system is selected.
