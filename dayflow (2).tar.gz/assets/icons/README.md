# Icon assets

Place optional branded icon exports here. Product UI uses `lucide-react-native` for consistent, replaceable icons.
