# Image assets

Add production exports for `logo.png`, the three onboarding illustrations, and `empty-state.png` here. The current demo uses icon primitives so it runs before brand artwork is available.
