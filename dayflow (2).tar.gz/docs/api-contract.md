# Frontend API Contract

These are frontend contracts only. Keep request and response types aligned here while the backend is finalized. All calls are centralized under `src/api/` and use `EXPO_PUBLIC_API_BASE_URL`.

## Authentication

```text
POST /auth/login
POST /auth/register
POST /auth/forgot-password
```

## Employees

```text
GET   /employees
GET   /employees/:id
POST  /employees
PATCH /employees/:id
```

## Attendance

```text
GET  /attendance?employeeId=:employeeId
POST /attendance/check-in
POST /attendance/check-out
POST /attendance/corrections
```

## Leave

```text
GET   /leaves?employeeId=:employeeId
POST  /leaves
PATCH /leaves/:id/approve
PATCH /leaves/:id/reject
```

## Payroll, notifications, and reports

```text
GET   /payroll?employeeId=:employeeId
GET   /payroll/:id/salary-slip
GET   /notifications
PATCH /notifications/:id/read
GET   /reports?type=:type
```

When the backend is available, replace mock calls inside the domain hooks/stores with the corresponding API functions. No route or component should need to know the server URL.
