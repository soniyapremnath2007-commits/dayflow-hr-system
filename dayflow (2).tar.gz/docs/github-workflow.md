# GitHub Workflow

## Branch map

```text
main
├── feature/auth-ui
├── feature/attendance-employees
├── feature/leave-notifications
└── feature/payroll-analytics
```

## Ownership

| Developer | Primary areas |
| --- | --- |
| Developer 1 | `(auth)`, `components/ui`, navigation, auth store/API/hook, theme |
| Developer 2 | Employee and HR attendance, employee management, employee/attendance components and APIs |
| Developer 3 | Employee and HR leave, notifications, leave/notification components and APIs |
| Developer 4 | Employee and HR payroll, HR reports, dashboard analytics, payroll/analytics components and APIs |

Shared UI changes should be discussed before editing. Route files stay intentionally thin so most work can happen independently inside each ownership area.

## Daily loop

```bash
git pull origin main
npm run typecheck
```

After a meaningful feature:

```bash
git add .
git commit -m "feat: meaningful description"
git push
```

Use meaningful messages such as `feat: add employee list`, `feat: implement attendance UI`, `fix: resolve leave validation`, or `integration: connect employee API`. Avoid `update`, `changes`, `working`, `test`, and `final`.

Before merging, test navigation, TypeScript, linting, mobile layout, and the relevant demo flow. Keep pull requests focused and rebase or merge `main` before requesting review.
