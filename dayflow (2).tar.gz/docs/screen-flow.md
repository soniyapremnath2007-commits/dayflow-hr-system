# Screen Flow

## Entry and authentication

```text
Launch
  ↓
Onboarding
  ↓
Login / Register / Forgot password
  ↓
Role detection
  ├─ EMPLOYEE → Employee dashboard
  └─ HR/ADMIN → HR dashboard
```

The root index chooses the first destination from the persisted Zustand auth store. The `(auth)`, `(employee)`, and `(hr)` layouts also guard their route groups, so navigation cannot be bypassed by manually entering a URL.

## Employee flow

```text
Employee dashboard
  ├─ Check in → attendance record is updated
  ├─ Attendance → history / calendar / correction
  ├─ Leave → apply → pending → details / cancel
  ├─ Payroll → salary slip / history
  ├─ Profile → personal information / documents / settings
  └─ Notifications
```

## HR/Admin flow

```text
HR dashboard
  ├─ Employees → search → profile → edit / documents
  ├─ Attendance → team log → details / corrections → approve or reject
  ├─ Leave → pending requests → request detail → approve or reject
  └─ More → payroll / reports / notifications / settings / help / about
```

## Hackathon demo path

1. Sign in with `employee@dayflow.demo` and `demo123`.
2. Check in from Home or Attendance.
3. Apply for leave and submit it.
4. Sign out, then sign in with `hr@dayflow.demo` and `demo123`.
5. Open Leave, review the pending request, and approve it.
6. Sign out and return to the Employee account to see the approved status.
7. Explore Payroll and the HR reports from More.
