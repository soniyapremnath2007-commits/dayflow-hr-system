import { apiClient } from './client'
import type { Attendance, AttendanceCorrection } from '@/types/attendance.types'

export const attendanceApi = {
  list: (employeeId?: string) => apiClient.get<Attendance[]>('/attendance', { params: { employeeId } }).then((response) => response.data),
  checkIn: () => apiClient.post<Attendance>('/attendance/check-in').then((response) => response.data),
  checkOut: () => apiClient.post<Attendance>('/attendance/check-out').then((response) => response.data),
  requestCorrection: (payload: Partial<AttendanceCorrection>) => apiClient.post<AttendanceCorrection>('/attendance/corrections', payload).then((response) => response.data),
}
