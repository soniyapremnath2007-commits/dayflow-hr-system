import { apiClient } from './client'
import type { LoginInput, User } from '@/types/auth.types'

export const authApi = {
  login: (payload: LoginInput) => apiClient.post<User>('/auth/login', payload).then((response) => response.data),
  register: (payload: Record<string, unknown>) => apiClient.post<User>('/auth/register', payload).then((response) => response.data),
  forgotPassword: (email: string) => apiClient.post<void>('/auth/forgot-password', { email }),
}
