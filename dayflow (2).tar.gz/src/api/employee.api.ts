import { apiClient } from './client'
import type { Employee } from '@/types/employee.types'

export const employeeApi = {
  list: () => apiClient.get<Employee[]>('/employees').then((response) => response.data),
  get: (id: string) => apiClient.get<Employee>(`/employees/${id}`).then((response) => response.data),
  create: (payload: Partial<Employee>) => apiClient.post<Employee>('/employees', payload).then((response) => response.data),
  update: (id: string, payload: Partial<Employee>) => apiClient.patch<Employee>(`/employees/${id}`, payload).then((response) => response.data),
}
