import { apiClient } from './client'
import type { LeaveRequest, LeaveStatus } from '@/types/leave.types'

export const leaveApi = {
  list: (employeeId?: string) => apiClient.get<LeaveRequest[]>('/leaves', { params: { employeeId } }).then((response) => response.data),
  create: (payload: Partial<LeaveRequest>) => apiClient.post<LeaveRequest>('/leaves', payload).then((response) => response.data),
  updateStatus: (id: string, status: LeaveStatus) => apiClient.patch<LeaveRequest>(`/leaves/${id}/${status.toLowerCase()}`, { status }).then((response) => response.data),
}
