import { apiClient } from './client'
import type { Notification } from '@/types/notification.types'

export const notificationApi = {
  list: () => apiClient.get<Notification[]>('/notifications').then((response) => response.data),
  markRead: (id: string) => apiClient.patch<Notification>(`/notifications/${id}/read`).then((response) => response.data),
}
