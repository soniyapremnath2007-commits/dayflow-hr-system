import { apiClient } from './client'
import type { Payroll, SalarySlip } from '@/types/payroll.types'

export const payrollApi = {
  list: (employeeId?: string) => apiClient.get<Payroll[]>('/payroll', { params: { employeeId } }).then((response) => response.data),
  getSalarySlip: (id: string) => apiClient.get<SalarySlip>(`/payroll/${id}/salary-slip`).then((response) => response.data),
}
