import { apiClient } from './client'
import type { Report } from '@/types/report.types'

export const reportApi = {
  list: (type?: string) => apiClient.get<Report[]>('/reports', { params: { type } }).then((response) => response.data),
}
