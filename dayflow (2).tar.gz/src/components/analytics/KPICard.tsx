import { TrendingDown, TrendingUp } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { Card } from '@/components/ui/Card'
import { colors } from '@/theme/colors'

export function KPICard({ label, value, trend, color = colors.primary }: { label: string; value: string; trend?: number; color?: string }) { const positive = (trend ?? 0) >= 0; return <Card style={styles.card}><Text style={styles.label}>{label}</Text><Text style={styles.value}>{value}</Text>{trend !== undefined && <View style={styles.trend}>{positive ? <TrendingUp size={14} color={colors.success} /> : <TrendingDown size={14} color={colors.error} />}<Text style={{ color: positive ? colors.success : colors.error, fontSize: 11, fontWeight: '700' }}>{Math.abs(trend)}% vs last month</Text></View>}<View style={[styles.accent, { backgroundColor: color }]} /></Card> }
const styles = StyleSheet.create({ card: { flex: 1, minWidth: '46%', borderRadius: 18, padding: 14, overflow: 'hidden' }, label: { color: colors.muted, fontSize: 11, fontWeight: '700' }, value: { color: colors.ink, fontSize: 21, fontWeight: '800', marginTop: 8 }, trend: { flexDirection: 'row', gap: 4, alignItems: 'center', marginTop: 7 }, accent: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 4 } })
