import { Clock3 } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { Card } from '@/components/ui/Card'
import { colors } from '@/theme/colors'
import { formatDate } from '@/utils/date'
import { AttendanceStatus } from './AttendanceStatus'
import type { Attendance } from '@/types/attendance.types'

export function AttendanceHistoryCard({ record }: { record: Attendance }) { return <Card style={styles.card}><View style={styles.date}><Text style={styles.day}>{new Date(`${record.date}T00:00:00`).getDate()}</Text><Text style={styles.month}>{new Date(`${record.date}T00:00:00`).toLocaleString('en-IN', { month: 'short' }).toUpperCase()}</Text></View><View style={styles.copy}><Text style={styles.title}>{formatDate(record.date, { weekday: 'long' })}</Text><View style={styles.meta}><Clock3 size={13} color={colors.muted} /><Text style={styles.time}>{record.checkIn ?? '--:--'} - {record.checkOut ?? '--:--'}</Text></View></View><View style={styles.right}><AttendanceStatus status={record.status} /><Text style={styles.hours}>{record.workHours ? `${record.workHours}h` : '-'}</Text></View></Card> }
const styles = StyleSheet.create({ card: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 18 }, date: { width: 42, height: 46, borderRadius: 12, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, day: { color: colors.primary, fontSize: 18, fontWeight: '800' }, month: { color: colors.primary, fontSize: 9, fontWeight: '800' }, copy: { flex: 1 }, title: { color: colors.ink, fontWeight: '700', fontSize: 13 }, meta: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 5 }, time: { color: colors.muted, fontSize: 11 }, right: { alignItems: 'flex-end', gap: 6 }, hours: { color: colors.ink, fontSize: 12, fontWeight: '700' } })
