import { Badge } from '@/components/ui/Badge'
import type { AttendanceStatus as Status } from '@/types/attendance.types'

export function AttendanceStatus({ status }: { status: Status }) { const tone = status === 'Present' ? 'success' : status === 'Late' ? 'warning' : status === 'Absent' ? 'error' : status === 'On leave' ? 'info' : 'neutral'; return <Badge label={status} tone={tone} /> }
