import { ArrowDownToLine, ArrowUpFromLine, CircleCheck } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { colors } from '@/theme/colors'
import type { Attendance } from '@/types/attendance.types'

export function CheckInCard({ record, onCheckIn, onCheckOut }: { record?: Attendance; onCheckIn: () => void; onCheckOut: () => void }) { const done = Boolean(record?.checkOut); return <Card><View style={styles.row}><View style={styles.icon}><CircleCheck size={21} color={colors.success} /></View><View style={styles.copy}><Text style={styles.title}>{done ? 'Day complete' : record?.checkIn ? 'You are checked in' : 'Start your workday'}</Text><Text style={styles.subtitle}>{done ? `Logged ${record?.workHours} hours today` : 'Keep your attendance up to date'}</Text></View></View>{!done && <Button label={record?.checkIn ? 'Check out' : 'Check in'} onPress={record?.checkIn ? onCheckOut : onCheckIn} icon={record?.checkIn ? <ArrowDownToLine size={17} color={colors.white} /> : <ArrowUpFromLine size={17} color={colors.white} />} />}</Card> }
const styles = StyleSheet.create({ row: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 18 }, icon: { width: 42, height: 42, borderRadius: 14, backgroundColor: colors.successSoft, alignItems: 'center', justifyContent: 'center' }, copy: { flex: 1 }, title: { color: colors.ink, fontWeight: '800', fontSize: 16 }, subtitle: { color: colors.muted, marginTop: 3, fontSize: 12 } })
