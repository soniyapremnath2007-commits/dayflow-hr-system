import { CalendarCheck2, Clock4, Percent, WalletCards } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { Card } from '@/components/ui/Card'
import { colors } from '@/theme/colors'

export function QuickStats({ attendance = 94, hours = '36.5h', leave = '12 days', salary = '₹1.10L' }: { attendance?: number; hours?: string; leave?: string; salary?: string }) { const items = [[Percent, `${attendance}%`, 'Attendance', colors.primary], [Clock4, hours, 'This week', colors.success], [CalendarCheck2, leave, 'Leave left', colors.warning], [WalletCards, salary, 'Net salary', '#9A65D6']] as const; return <View style={styles.grid}>{items.map(([Icon, value, label, color]) => <Card key={label} style={styles.card}><View style={[styles.icon, { backgroundColor: `${color}16` }]}><Icon size={17} color={color} /></View><Text style={styles.value}>{value}</Text><Text style={styles.label}>{label}</Text></Card>)}</View> }
const styles = StyleSheet.create({ grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 }, card: { width: '48%', padding: 14, borderRadius: 18 }, icon: { width: 31, height: 31, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginBottom: 10 }, value: { color: colors.ink, fontSize: 18, fontWeight: '800' }, label: { color: colors.muted, fontSize: 12, marginTop: 2 } })
