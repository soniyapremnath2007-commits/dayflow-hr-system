import { CheckCircle2, FileText, IndianRupee } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { Card } from '@/components/ui/Card'
import { colors } from '@/theme/colors'

const icons = { leave: FileText, attendance: CheckCircle2, payroll: IndianRupee }
export function RecentActivity() { const items = [{ type: 'leave', title: 'Leave request submitted', time: 'Today, 9:42 AM' }, { type: 'attendance', title: 'Checked in for the day', time: 'Today, 9:12 AM' }, { type: 'payroll', title: 'Salary slip generated', time: '01 Aug 2026' }]; return <Card><Text style={styles.title}>Recent activity</Text><View style={styles.list}>{items.map((item) => { const Icon = icons[item.type as keyof typeof icons]; return <View style={styles.item} key={item.title}><View style={styles.icon}><Icon size={16} color={colors.primary} /></View><View style={styles.copy}><Text style={styles.itemTitle}>{item.title}</Text><Text style={styles.time}>{item.time}</Text></View></View> })}</View></Card> }
const styles = StyleSheet.create({ title: { color: colors.ink, fontSize: 16, fontWeight: '800' }, list: { gap: 16, marginTop: 18 }, item: { flexDirection: 'row', alignItems: 'center', gap: 10 }, icon: { width: 34, height: 34, borderRadius: 11, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, copy: { flex: 1 }, itemTitle: { color: colors.ink, fontSize: 13, fontWeight: '700' }, time: { color: colors.muted, fontSize: 11, marginTop: 3 } })
