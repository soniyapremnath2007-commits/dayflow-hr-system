import { Bell } from '@/components/ui/icons'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { Avatar } from '@/components/ui/Avatar'
import { colors } from '@/theme/colors'
import type { User } from '@/types/auth.types'

export function WelcomeHeader({ user, onNotifications }: { user: User; onNotifications: () => void }) { return <View style={styles.row}><Avatar name={user.name} size={48} /><View style={styles.copy}><Text style={styles.eyebrow}>GOOD MORNING</Text><Text style={styles.name}>{user.name.split(' ')[0]} <Text style={styles.wave}>✦</Text></Text><Text style={styles.department}>{user.department} · {user.employeeId}</Text></View><Pressable onPress={onNotifications} style={styles.bell}><Bell size={20} color={colors.ink} /></Pressable></View> }
const styles = StyleSheet.create({ row: { flexDirection: 'row', alignItems: 'center', gap: 12 }, copy: { flex: 1 }, eyebrow: { color: colors.primary, fontSize: 10, fontWeight: '800', letterSpacing: 1.5 }, name: { color: colors.ink, fontSize: 24, fontWeight: '800', marginTop: 2 }, wave: { color: colors.primary }, department: { color: colors.muted, fontSize: 12, marginTop: 2 }, bell: { width: 42, height: 42, borderRadius: 14, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.border } })
