import { ChevronRight } from '@/components/ui/icons'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { Avatar } from '@/components/ui/Avatar'
import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { colors } from '@/theme/colors'
import type { Employee } from '@/types/employee.types'

export function EmployeeCard({ employee, onPress }: { employee: Employee; onPress?: () => void }) { return <Pressable onPress={onPress}><Card style={styles.card}><Avatar name={employee.name} color={employee.avatarColor} size={42} /><View style={styles.copy}><Text style={styles.name}>{employee.name}</Text><Text style={styles.role}>{employee.role} · {employee.department}</Text></View><View style={styles.right}><Badge label={employee.status} tone={employee.status === 'Active' ? 'success' : 'warning'} /><ChevronRight size={16} color={colors.muted} /></View></Card></Pressable> }
const styles = StyleSheet.create({ card: { padding: 12, borderRadius: 18, flexDirection: 'row', alignItems: 'center', gap: 11 }, copy: { flex: 1 }, name: { color: colors.ink, fontSize: 13, fontWeight: '800' }, role: { color: colors.muted, fontSize: 11, marginTop: 4 }, right: { alignItems: 'flex-end', gap: 7 } })
