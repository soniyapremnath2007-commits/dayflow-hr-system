import { Mail, Phone } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { Avatar } from '@/components/ui/Avatar'
import { Card } from '@/components/ui/Card'
import { colors } from '@/theme/colors'
import type { Employee } from '@/types/employee.types'

export function EmployeeHeader({ employee }: { employee: Employee }) { return <Card style={styles.card}><Avatar name={employee.name} color={employee.avatarColor} size={68} /><View style={styles.copy}><Text style={styles.name}>{employee.name}</Text><Text style={styles.role}>{employee.role}</Text><Text style={styles.id}>{employee.employeeId} · {employee.department}</Text></View><View style={styles.contacts}><View style={styles.contact}><Mail size={14} color={colors.primary} /><Text style={styles.contactText}>{employee.email}</Text></View><View style={styles.contact}><Phone size={14} color={colors.primary} /><Text style={styles.contactText}>{employee.phone}</Text></View></View></Card> }
const styles = StyleSheet.create({ card: { gap: 12, alignItems: 'center' }, copy: { alignItems: 'center' }, name: { color: colors.ink, fontSize: 19, fontWeight: '800' }, role: { color: colors.muted, fontSize: 13, marginTop: 3 }, id: { color: colors.primary, fontSize: 11, fontWeight: '700', marginTop: 6 }, contacts: { width: '100%', gap: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: colors.border }, contact: { flexDirection: 'row', alignItems: 'center', gap: 8 }, contactText: { color: colors.muted, fontSize: 12 } })
