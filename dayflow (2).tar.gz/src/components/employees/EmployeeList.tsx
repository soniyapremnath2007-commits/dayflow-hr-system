import { StyleSheet, View } from 'react-native'
import { EmployeeCard } from './EmployeeCard'
import type { Employee } from '@/types/employee.types'
export function EmployeeList({ employees, onSelect }: { employees: Employee[]; onSelect: (employee: Employee) => void }) { return <View style={styles.list}>{employees.map((employee) => <EmployeeCard key={employee.id} employee={employee} onPress={() => onSelect(employee)} />)}</View> }
const styles = StyleSheet.create({ list: { gap: 10 } })
