import { zodResolver } from '@hookform/resolvers/zod'
import { Controller, useForm } from 'react-hook-form'
import { StyleSheet, Text, View } from 'react-native'
import { Button } from '@/components/ui/Button'
import { Dropdown } from '@/components/ui/Dropdown'
import { Input } from '@/components/ui/Input'
import { LEAVE_TYPES } from '@/constants/leaveTypes'
import { colors } from '@/theme/colors'
import { leaveSchema, type LeaveFormValues } from '@/validation/leave.schema'

export function LeaveForm({ onSubmit }: { onSubmit: (values: LeaveFormValues) => void }) { const { control, handleSubmit, formState: { errors, isSubmitting }, setValue, watch } = useForm<LeaveFormValues>({ resolver: zodResolver(leaveSchema), defaultValues: { type: 'Annual', startDate: '', endDate: '', reason: '' } }); const type = watch('type'); const nextType = () => setValue('type', LEAVE_TYPES[(LEAVE_TYPES.indexOf(type) + 1) % LEAVE_TYPES.length], { shouldValidate: true }); return <View style={styles.form}><Controller control={control} name="type" render={() => <Dropdown label="Leave type" value={type} onPress={nextType} />} /><View style={styles.row}><View style={styles.half}><Controller control={control} name="startDate" render={({ field: { onChange, value } }) => <Input label="From" placeholder="YYYY-MM-DD" value={value} onChangeText={onChange} error={errors.startDate?.message} />} /></View><View style={styles.half}><Controller control={control} name="endDate" render={({ field: { onChange, value } }) => <Input label="To" placeholder="YYYY-MM-DD" value={value} onChangeText={onChange} error={errors.endDate?.message} />} /></View></View><Controller control={control} name="reason" render={({ field: { onChange, value } }) => <Input label="Reason" placeholder="Tell your manager why you need leave" value={value} onChangeText={onChange} multiline numberOfLines={4} textAlignVertical="top" style={styles.reason} error={errors.reason?.message} />} /><Text style={styles.note}>Your request will be sent to People Operations for approval.</Text><Button label="Submit leave request" onPress={handleSubmit(onSubmit)} loading={isSubmitting} /></View> }
const styles = StyleSheet.create({ form: { gap: 16 }, row: { flexDirection: 'row', gap: 10 }, half: { flex: 1 }, reason: { minHeight: 92, paddingTop: 14 }, note: { color: colors.muted, fontSize: 12, lineHeight: 18 } })
