import { CalendarDays, ChevronRight } from '@/components/ui/icons'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { Card } from '@/components/ui/Card'
import { colors } from '@/theme/colors'
import { formatDate } from '@/utils/date'
import { LeaveStatusBadge } from './LeaveStatusBadge'
import type { LeaveRequest } from '@/types/leave.types'

export function LeaveRequestCard({ request, onPress }: { request: LeaveRequest; onPress?: () => void }) { return <Pressable onPress={onPress}><Card style={styles.card}><View style={styles.icon}><CalendarDays size={19} color={colors.primary} /></View><View style={styles.copy}><Text style={styles.title}>{request.type} leave <Text style={styles.days}>· {request.days} {request.days === 1 ? 'day' : 'days'}</Text></Text><Text style={styles.date}>{formatDate(request.startDate)}{request.startDate !== request.endDate ? ` - ${formatDate(request.endDate)}` : ''}</Text></View><View style={styles.right}><LeaveStatusBadge status={request.status} /><ChevronRight size={17} color={colors.muted} /></View></Card></Pressable> }
const styles = StyleSheet.create({ card: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 13, borderRadius: 18 }, icon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.primarySoft }, copy: { flex: 1 }, title: { color: colors.ink, fontSize: 13, fontWeight: '800' }, days: { color: colors.muted, fontWeight: '500' }, date: { color: colors.muted, fontSize: 11, marginTop: 4 }, right: { alignItems: 'flex-end', gap: 7 } })
