import { Badge } from '@/components/ui/Badge'
import type { LeaveStatus } from '@/types/leave.types'
export function LeaveStatusBadge({ status }: { status: LeaveStatus }) { return <Badge label={status} tone={status === 'Approved' ? 'success' : status === 'Rejected' ? 'error' : status === 'Pending' ? 'warning' : 'neutral'} /> }
