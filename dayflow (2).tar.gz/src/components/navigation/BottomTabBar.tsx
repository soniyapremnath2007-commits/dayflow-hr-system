import { StyleSheet, Text, View } from 'react-native'
import { colors } from '@/theme/colors'

export function BottomTabBar({ labels }: { labels: string[] }) { return <View style={styles.bar}>{labels.map((label, index) => <View key={label} style={styles.item}><View style={[styles.icon, index === 0 && styles.selected]} /><Text style={[styles.label, index === 0 && styles.selectedText]}>{label}</Text></View>)}</View> }
const styles = StyleSheet.create({ bar: { flexDirection: 'row', padding: 12, backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border }, item: { flex: 1, alignItems: 'center', gap: 5 }, icon: { width: 18, height: 18, borderRadius: 6, backgroundColor: colors.border }, selected: { backgroundColor: colors.primary }, label: { color: colors.muted, fontSize: 10, fontWeight: '600' }, selectedText: { color: colors.primary } })
