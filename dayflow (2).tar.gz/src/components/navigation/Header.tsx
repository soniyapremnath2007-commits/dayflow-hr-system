import { Bell, ChevronLeft } from '@/components/ui/icons'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { useRouter } from 'expo-router'
import { colors } from '@/theme/colors'
import { useNotifications } from '@/hooks/useNotifications'

export function Header({ title, subtitle, back = false, onNotification }: { title: string; subtitle?: string; back?: boolean; onNotification?: () => void }) {
  const router = useRouter()
  const { unreadCount } = useNotifications()
  return <View style={styles.row}>{back && <Pressable onPress={() => router.back()} style={styles.back}><ChevronLeft size={21} color={colors.ink} /></Pressable>}<View style={styles.copy}><Text style={styles.title}>{title}</Text>{subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}</View>{onNotification && <Pressable onPress={onNotification} style={styles.bell}><Bell size={20} color={colors.ink} />{unreadCount > 0 && <View style={styles.dot} />}</Pressable>}</View>
}
const styles = StyleSheet.create({ row: { minHeight: 44, flexDirection: 'row', alignItems: 'center', gap: 10 }, back: { width: 38, height: 38, borderRadius: 12, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.surface }, copy: { flex: 1, gap: 2 }, title: { color: colors.ink, fontSize: 22, lineHeight: 28, fontWeight: '800' }, subtitle: { color: colors.muted, fontSize: 12 }, bell: { width: 42, height: 42, borderRadius: 14, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' }, dot: { position: 'absolute', top: 9, right: 10, width: 7, height: 7, borderRadius: 7, backgroundColor: colors.error } })
