import { Bell } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { colors } from '@/theme/colors'
export function NotificationBadge({ count }: { count: number }) { return <View style={styles.wrap}><Bell size={18} color={colors.primary} />{count > 0 && <View style={styles.badge}><Text style={styles.text}>{count > 9 ? '9+' : count}</Text></View>}</View> }
const styles = StyleSheet.create({ wrap: { width: 34, height: 34, borderRadius: 11, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, badge: { position: 'absolute', top: -4, right: -4, minWidth: 16, height: 16, borderRadius: 99, paddingHorizontal: 3, backgroundColor: colors.error, alignItems: 'center', justifyContent: 'center' }, text: { color: colors.white, fontSize: 9, fontWeight: '800' } })
