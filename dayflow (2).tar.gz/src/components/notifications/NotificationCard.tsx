import { CalendarClock, CircleDollarSign, Info, UserCheck } from '@/components/ui/icons'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { Card } from '@/components/ui/Card'
import { colors } from '@/theme/colors'
import type { Notification } from '@/types/notification.types'

const icons = { leave: CalendarClock, attendance: UserCheck, payroll: CircleDollarSign, system: Info }
export function NotificationCard({ notification, onPress }: { notification: Notification; onPress?: () => void }) { const Icon = icons[notification.type]; return <Pressable onPress={onPress}><Card style={[styles.card, !notification.read && styles.unread]}><View style={styles.icon}><Icon size={18} color={colors.primary} /></View><View style={styles.copy}><Text style={styles.title}>{notification.title}</Text><Text style={styles.message}>{notification.message}</Text><Text style={styles.time}>{notification.time}</Text></View>{!notification.read && <View style={styles.dot} />}</Card></Pressable> }
const styles = StyleSheet.create({ card: { flexDirection: 'row', gap: 11, padding: 13, borderRadius: 18 }, unread: { backgroundColor: '#FBFCFF', borderColor: '#CAD5FF' }, icon: { width: 38, height: 38, borderRadius: 12, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, copy: { flex: 1 }, title: { color: colors.ink, fontSize: 13, fontWeight: '800' }, message: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 4 }, time: { color: colors.muted, fontSize: 10, marginTop: 7 }, dot: { width: 7, height: 7, borderRadius: 7, backgroundColor: colors.primary, marginTop: 4 } })
