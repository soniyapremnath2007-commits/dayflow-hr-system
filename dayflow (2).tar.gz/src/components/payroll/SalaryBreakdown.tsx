import { StyleSheet, Text, View } from 'react-native'
import { Card } from '@/components/ui/Card'
import { colors } from '@/theme/colors'
import { formatCurrency } from '@/utils/currency'
import type { SalarySlip } from '@/types/payroll.types'

export function SalaryBreakdown({ slip }: { slip: SalarySlip }) { return <Card><Text style={styles.title}>Salary breakdown</Text><View style={styles.list}>{slip.allowances.map((item) => <View style={styles.row} key={item.label}><Text style={styles.label}>{item.label}</Text><Text style={styles.amount}>{formatCurrency(item.amount)}</Text></View>)}<View style={styles.rule} />{slip.deductionItems.map((item) => <View style={styles.row} key={item.label}><Text style={styles.label}>{item.label}</Text><Text style={[styles.amount, { color: colors.error }]}>- {formatCurrency(item.amount)}</Text></View>)}<View style={styles.total}><Text style={styles.totalLabel}>Net salary</Text><Text style={styles.totalAmount}>{formatCurrency(slip.net)}</Text></View></View></Card> }
const styles = StyleSheet.create({ title: { color: colors.ink, fontSize: 16, fontWeight: '800' }, list: { gap: 13, marginTop: 18 }, row: { flexDirection: 'row', justifyContent: 'space-between' }, label: { color: colors.muted, fontSize: 13 }, amount: { color: colors.ink, fontSize: 13, fontWeight: '700' }, rule: { height: 1, backgroundColor: colors.border }, total: { flexDirection: 'row', justifyContent: 'space-between', paddingTop: 4 }, totalLabel: { color: colors.ink, fontSize: 14, fontWeight: '800' }, totalAmount: { color: colors.primary, fontSize: 17, fontWeight: '800' } })
