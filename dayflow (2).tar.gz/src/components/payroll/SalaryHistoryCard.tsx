import { ChevronRight, FileText } from '@/components/ui/icons'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { Card } from '@/components/ui/Card'
import { colors } from '@/theme/colors'
import { formatCurrency } from '@/utils/currency'
import type { Payroll } from '@/types/payroll.types'

export function SalaryHistoryCard({ item, onPress }: { item: Payroll; onPress?: () => void }) { return <Pressable onPress={onPress}><Card style={styles.card}><View style={styles.icon}><FileText size={17} color={colors.primary} /></View><View style={styles.copy}><Text style={styles.month}>{item.month}</Text><Text style={styles.status}>{item.status} · {item.paidOn}</Text></View><Text style={styles.amount}>{formatCurrency(item.net)}</Text><ChevronRight size={16} color={colors.muted} /></Card></Pressable> }
const styles = StyleSheet.create({ card: { padding: 13, flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: 18 }, icon: { width: 37, height: 37, borderRadius: 11, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, copy: { flex: 1 }, month: { color: colors.ink, fontSize: 13, fontWeight: '800' }, status: { color: colors.muted, fontSize: 11, marginTop: 4 }, amount: { color: colors.ink, fontSize: 12, fontWeight: '800' } })
