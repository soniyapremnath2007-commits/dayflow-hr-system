import { Download, FileText } from '@/components/ui/icons'
import { Alert, StyleSheet, Text, View } from 'react-native'
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { colors } from '@/theme/colors'
import { formatCurrency } from '@/utils/currency'
import type { SalarySlip as SalarySlipType } from '@/types/payroll.types'

export function SalarySlip({ slip, onDownload }: { slip: SalarySlipType; onDownload?: () => void }) { const download = onDownload ?? (() => Alert.alert('Salary slip', 'Download is ready to connect to your payroll provider.')); return <Card><View style={styles.head}><View style={styles.icon}><FileText size={20} color={colors.primary} /></View><View style={styles.copy}><Text style={styles.title}>{slip.month} salary slip</Text><Text style={styles.subtitle}>Generated on {slip.paidOn}</Text></View></View><View style={styles.total}><Text style={styles.label}>Net pay</Text><Text style={styles.amount}>{formatCurrency(slip.net)}</Text></View><Button label="Download salary slip" variant="secondary" onPress={download} icon={<Download size={17} color={colors.primary} />} /></Card> }
const styles = StyleSheet.create({ head: { flexDirection: 'row', gap: 11, alignItems: 'center' }, icon: { width: 42, height: 42, borderRadius: 13, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' }, copy: { flex: 1 }, title: { color: colors.ink, fontSize: 16, fontWeight: '800' }, subtitle: { color: colors.muted, fontSize: 12, marginTop: 3 }, total: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 20, paddingVertical: 16, borderTopWidth: 1, borderBottomWidth: 1, borderColor: colors.border }, label: { color: colors.muted, fontSize: 13 }, amount: { color: colors.primary, fontSize: 22, fontWeight: '800' } })
