import { StyleSheet, Text, View } from 'react-native'
import { colors } from '@/theme/colors'

export function Avatar({ name, color = colors.primary, size = 44 }: { name: string; color?: string; size?: number }) {
  const initials = name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase()
  return <View style={[styles.base, { width: size, height: size, borderRadius: size / 2, backgroundColor: color }]}><Text style={[styles.text, { fontSize: size * 0.32 }]}>{initials}</Text></View>
}
const styles = StyleSheet.create({ base: { alignItems: 'center', justifyContent: 'center' }, text: { color: colors.white, fontWeight: '800' } })
