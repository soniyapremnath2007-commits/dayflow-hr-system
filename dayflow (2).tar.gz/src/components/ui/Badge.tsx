import { StyleSheet, Text } from 'react-native'
import { colors } from '@/theme/colors'

type Tone = 'success' | 'warning' | 'error' | 'info' | 'neutral'
export function Badge({ label, tone = 'neutral' }: { label: string; tone?: Tone }) {
  return <Text style={[styles.base, styles[`${tone}Text` as keyof typeof styles], styles[`${tone}Bg` as keyof typeof styles]]}>{label}</Text>
}
const styles = StyleSheet.create({ base: { alignSelf: 'flex-start', borderRadius: 99, paddingHorizontal: 10, paddingVertical: 5, fontSize: 11, fontWeight: '700' }, successText: { color: colors.success }, warningText: { color: colors.warning }, errorText: { color: colors.error }, infoText: { color: colors.info }, neutralText: { color: colors.muted }, successBg: { backgroundColor: colors.successSoft }, warningBg: { backgroundColor: colors.warningSoft }, errorBg: { backgroundColor: colors.errorSoft }, infoBg: { backgroundColor: '#E7F3FB' }, neutralBg: { backgroundColor: '#EFF1F6' } })
