import type { ReactNode } from 'react'
import { Modal, Pressable, StyleSheet, Text, View } from 'react-native'
import { colors } from '@/theme/colors'

export function BottomSheet({ visible, onClose, title, children }: { visible: boolean; onClose: () => void; title: string; children: ReactNode }) {
  return <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}><Pressable style={styles.backdrop} onPress={onClose}><View style={styles.sheet} onStartShouldSetResponder={() => true}><View style={styles.handle} /><Text style={styles.title}>{title}</Text>{children}</View></Pressable></Modal>
}
const styles = StyleSheet.create({ backdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(15,23,54,.4)' }, sheet: { backgroundColor: colors.surface, padding: 24, paddingBottom: 34, borderTopLeftRadius: 28, borderTopRightRadius: 28, gap: 16 }, handle: { alignSelf: 'center', width: 42, height: 5, borderRadius: 99, backgroundColor: colors.border }, title: { color: colors.ink, fontSize: 18, fontWeight: '800' } })
