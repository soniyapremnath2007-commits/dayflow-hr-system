import type { ReactNode } from 'react'
import { ActivityIndicator, Pressable, StyleSheet, Text } from 'react-native'
import { colors } from '@/theme/colors'
import { spacing } from '@/theme/spacing'

type Props = { label: string; onPress?: () => void; variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; size?: 'sm' | 'md'; loading?: boolean; icon?: ReactNode; disabled?: boolean }

export function Button({ label, onPress, variant = 'primary', size = 'md', loading, icon, disabled }: Props) {
  const textColor = variant === 'primary' ? colors.white : variant === 'danger' ? colors.error : colors.primary
  return <Pressable accessibilityRole="button" onPress={onPress} disabled={disabled || loading} style={({ pressed }) => [styles.base, styles[size], styles[variant], pressed && styles.pressed, disabled && styles.disabled]}>
    {loading ? <ActivityIndicator color={textColor} /> : <>{icon}{<Text style={[styles.label, { color: textColor }]}>{label}</Text>}</>}
  </Pressable>
}

const styles = StyleSheet.create({
  base: { borderRadius: 14, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8 },
  sm: { minHeight: 38, paddingHorizontal: 14 }, md: { minHeight: 52, paddingHorizontal: 20 },
  primary: { backgroundColor: colors.primary }, secondary: { backgroundColor: colors.primarySoft }, ghost: { backgroundColor: 'transparent' }, danger: { backgroundColor: colors.errorSoft },
  label: { fontSize: 14, fontWeight: '700' }, pressed: { opacity: 0.8 }, disabled: { opacity: 0.45 },
})
