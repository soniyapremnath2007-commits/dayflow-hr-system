import type { ReactNode } from 'react'
import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native'
import { colors } from '@/theme/colors'
import { shadows } from '@/theme/shadows'
import { spacing } from '@/theme/spacing'

export function Card({ children, style, padded = true }: { children: ReactNode; style?: StyleProp<ViewStyle>; padded?: boolean }) {
  return <View style={[styles.card, padded && styles.padded, style]}>{children}</View>
}
const styles = StyleSheet.create({ card: { backgroundColor: colors.surface, borderRadius: 22, borderWidth: 1, borderColor: colors.border, ...shadows.card }, padded: { padding: spacing.lg } })
