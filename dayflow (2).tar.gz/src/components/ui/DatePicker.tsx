import { CalendarDays } from '@/components/ui/icons'
import { Pressable, StyleSheet, Text } from 'react-native'
import { colors } from '@/theme/colors'
export function DatePicker({ value, onPress, label }: { value: string; onPress?: () => void; label?: string }) { return <Pressable onPress={onPress} style={styles.wrap}><CalendarDays size={17} color={colors.primary} /><Text style={styles.text}>{label ? `${label}: ` : ''}{value}</Text></Pressable> }
const styles = StyleSheet.create({ wrap: { minHeight: 48, borderRadius: 14, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 8 }, text: { color: colors.ink, fontSize: 14 } })
