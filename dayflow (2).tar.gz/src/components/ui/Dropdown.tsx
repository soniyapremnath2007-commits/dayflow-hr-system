import { ChevronDown } from '@/components/ui/icons'
import { Pressable, StyleSheet, Text, View } from 'react-native'
import { colors } from '@/theme/colors'
export function Dropdown({ label, value, onPress }: { label: string; value: string; onPress?: () => void }) { return <View style={styles.wrap}><Text style={styles.label}>{label}</Text><Pressable onPress={onPress} style={styles.field}><Text style={styles.value}>{value}</Text><ChevronDown size={17} color={colors.muted} /></Pressable></View> }
const styles = StyleSheet.create({ wrap: { gap: 7 }, label: { color: colors.ink, fontSize: 13, fontWeight: '700' }, field: { minHeight: 50, borderRadius: 14, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, value: { color: colors.ink, fontSize: 14 } })
