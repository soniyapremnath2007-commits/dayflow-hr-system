import { Inbox } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { colors } from '@/theme/colors'
export function EmptyState({ title, message }: { title: string; message: string }) { return <View style={styles.wrap}><Inbox size={30} color={colors.primary} /><Text style={styles.title}>{title}</Text><Text style={styles.message}>{message}</Text></View> }
const styles = StyleSheet.create({ wrap: { padding: 28, alignItems: 'center', gap: 8 }, title: { color: colors.ink, fontWeight: '800', fontSize: 16 }, message: { color: colors.muted, textAlign: 'center', fontSize: 13 } })
