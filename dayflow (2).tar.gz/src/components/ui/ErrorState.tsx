import { AlertCircle } from '@/components/ui/icons'
import { StyleSheet, Text, View } from 'react-native'
import { colors } from '@/theme/colors'
export function ErrorState({ message = 'Something went wrong.' }: { message?: string }) { return <View style={styles.wrap}><AlertCircle size={28} color={colors.error} /><Text style={styles.text}>{message}</Text></View> }
const styles = StyleSheet.create({ wrap: { alignItems: 'center', gap: 8, padding: 24 }, text: { color: colors.error, fontSize: 13 } })
