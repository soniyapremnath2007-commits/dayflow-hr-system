import { forwardRef } from 'react'
import { StyleSheet, Text, TextInput, type TextInputProps, View } from 'react-native'
import { colors } from '@/theme/colors'
import { spacing } from '@/theme/spacing'

type Props = TextInputProps & { label?: string; error?: string; hint?: string }
export const Input = forwardRef<TextInput, Props>(function Input({ label, error, hint, style, ...props }, ref) {
  return <View style={styles.wrap}>
    {label && <Text style={styles.label}>{label}</Text>}
    <TextInput ref={ref} placeholderTextColor={colors.muted} style={[styles.input, error && styles.inputError, style]} {...props} />
    {!!error && <Text style={styles.error}>{error}</Text>}
    {!!hint && !error && <Text style={styles.hint}>{hint}</Text>}
  </View>
})

const styles = StyleSheet.create({ wrap: { gap: 7 }, label: { color: colors.ink, fontSize: 13, fontWeight: '700' }, input: { minHeight: 50, borderRadius: 14, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, paddingHorizontal: spacing.lg, color: colors.ink, fontSize: 15 }, inputError: { borderColor: colors.error }, error: { color: colors.error, fontSize: 12 }, hint: { color: colors.muted, fontSize: 12 } })
