import type { ReactNode } from 'react'
import { Modal as NativeModal, Pressable, StyleSheet, Text, View } from 'react-native'
import { X } from '@/components/ui/icons'
import { colors } from '@/theme/colors'
import { spacing } from '@/theme/spacing'

export function Modal({ visible, onClose, title, children }: { visible: boolean; onClose: () => void; title: string; children: ReactNode }) {
  return <NativeModal visible={visible} transparent animationType="fade" onRequestClose={onClose}><View style={styles.overlay}><View style={styles.card}><View style={styles.header}><Text style={styles.title}>{title}</Text><Pressable onPress={onClose} hitSlop={12}><X size={20} color={colors.muted} /></Pressable></View>{children}</View></View></NativeModal>
}
const styles = StyleSheet.create({ overlay: { flex: 1, backgroundColor: 'rgba(15, 23, 54, 0.45)', alignItems: 'center', justifyContent: 'center', padding: spacing.xl }, card: { backgroundColor: colors.surface, borderRadius: 24, padding: spacing.xl, width: '100%', gap: spacing.lg }, header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, title: { color: colors.ink, fontSize: 18, fontWeight: '800' } })
