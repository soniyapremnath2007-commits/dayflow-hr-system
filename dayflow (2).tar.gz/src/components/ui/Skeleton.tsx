import { StyleSheet, View } from 'react-native'
import { colors } from '@/theme/colors'
export function Skeleton({ width = '100%', height = 18 }: { width?: number | `${number}%`; height?: number }) { return <View style={[styles.base, { width, height }]} /> }
const styles = StyleSheet.create({ base: { borderRadius: 8, backgroundColor: colors.border } })
