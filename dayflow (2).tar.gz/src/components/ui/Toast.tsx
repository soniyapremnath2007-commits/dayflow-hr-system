import { StyleSheet, Text, View } from 'react-native'
import { CheckCircle2 } from '@/components/ui/icons'
import { colors } from '@/theme/colors'

export function Toast({ message }: { message: string }) { return <View style={styles.toast}><CheckCircle2 size={18} color={colors.success} /><Text style={styles.text}>{message}</Text></View> }
const styles = StyleSheet.create({ toast: { flexDirection: 'row', gap: 8, alignItems: 'center', padding: 14, borderRadius: 14, backgroundColor: colors.successSoft }, text: { flex: 1, color: colors.success, fontSize: 13, fontWeight: '700' } })
