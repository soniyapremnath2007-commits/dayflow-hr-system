import { Pressable, StyleSheet, View } from 'react-native'
import { colors } from '@/theme/colors'
export function Toggle({ value, onChange }: { value: boolean; onChange: (value: boolean) => void }) { return <Pressable onPress={() => onChange(!value)} style={[styles.track, value && styles.active]}><View style={[styles.thumb, value && styles.thumbActive]} /></Pressable> }
const styles = StyleSheet.create({ track: { width: 48, height: 28, borderRadius: 99, backgroundColor: colors.border, padding: 3, justifyContent: 'center' }, active: { backgroundColor: colors.primary }, thumb: { height: 22, width: 22, borderRadius: 99, backgroundColor: colors.white }, thumbActive: { alignSelf: 'flex-end' } })
