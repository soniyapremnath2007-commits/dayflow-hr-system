import type { AttendanceStatus } from '@/types/attendance.types'

export const ATTENDANCE_STATUSES: AttendanceStatus[] = ['Present', 'Absent', 'Late', 'On leave', 'Half day']
