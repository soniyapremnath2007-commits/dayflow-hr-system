export { colors } from '@/theme/colors'
