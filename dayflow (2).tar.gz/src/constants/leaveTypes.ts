import type { LeaveType } from '@/types/leave.types'

export const LEAVE_TYPES: LeaveType[] = ['Annual', 'Sick', 'Personal', 'Work from home']
