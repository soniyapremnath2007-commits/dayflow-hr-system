export const ROLES = {
  EMPLOYEE: 'EMPLOYEE',
  HR: 'HR',
  ADMIN: 'ADMIN',
} as const

export type Role = (typeof ROLES)[keyof typeof ROLES]

export const HR_ROLES: Role[] = [ROLES.HR, ROLES.ADMIN]
