export const ROUTES = {
  auth: '/(auth)/login',
  employee: '/(employee)/(tabs)',
  hr: '/(hr)/(tabs)',
  employeeAttendance: '/(employee)/(tabs)/attendance',
  employeeLeave: '/(employee)/(tabs)/leave',
  employeePayroll: '/(employee)/(tabs)/payroll',
  hrEmployees: '/(hr)/(tabs)/employees',
  hrLeave: '/(hr)/(tabs)/leave',
} as const
