import type { Attendance, AttendanceCorrection } from '@/types/attendance.types'

const daysAgo = (days: number) => {
  const date = new Date()
  date.setDate(date.getDate() - days)
  return date.toISOString().slice(0, 10)
}

export const mockAttendance: Attendance[] = [
  { id: 'att-1', employeeId: 'e-001', date: daysAgo(0), checkIn: '09:12', status: 'Present', workHours: 4.3 },
  { id: 'att-2', employeeId: 'e-001', date: daysAgo(1), checkIn: '09:04', checkOut: '18:02', status: 'Present', workHours: 8.9 },
  { id: 'att-3', employeeId: 'e-001', date: daysAgo(2), checkIn: '09:31', checkOut: '18:10', status: 'Late', workHours: 8.6 },
  { id: 'att-4', employeeId: 'e-001', date: daysAgo(3), checkIn: '08:56', checkOut: '17:45', status: 'Present', workHours: 8.8 },
  { id: 'att-5', employeeId: 'e-001', date: daysAgo(4), status: 'On leave', workHours: 0 },
  { id: 'att-6', employeeId: 'e-002', date: daysAgo(0), checkIn: '08:48', checkOut: '17:42', status: 'Present', workHours: 8.9 },
  { id: 'att-7', employeeId: 'e-003', date: daysAgo(0), status: 'On leave', workHours: 0 },
  { id: 'att-8', employeeId: 'e-004', date: daysAgo(0), checkIn: '09:17', status: 'Present', workHours: 4.1 },
]

export const mockCorrections: AttendanceCorrection[] = [
  { id: 'cor-1', attendanceId: 'att-3', employeeId: 'e-001', date: daysAgo(2), requestedCheckIn: '09:00', requestedCheckOut: '18:10', reason: 'Client call started early', status: 'Pending' },
]
