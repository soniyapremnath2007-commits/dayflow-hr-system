import type { Department, Employee } from '@/types/employee.types'

export const mockDepartments: Department[] = [
  { id: 'd-1', name: 'Product', headcount: 18, color: '#3154D8' },
  { id: 'd-2', name: 'Engineering', headcount: 42, color: '#1C9B72' },
  { id: 'd-3', name: 'Sales', headcount: 24, color: '#D58B16' },
  { id: 'd-4', name: 'People Ops', headcount: 8, color: '#9A65D6' },
]

export const mockEmployees: Employee[] = [
  { id: 'e-001', employeeId: 'DF-1001', name: 'Employee Demo', email: 'employee@dayflow.demo', phone: '+91 98765 43210', department: 'Product', role: 'Product Designer', employmentType: 'Full-time', joiningDate: '2023-06-12', location: 'Bengaluru', status: 'Active', salary: 125000, avatarColor: '#3154D8' },
  { id: 'e-002', employeeId: 'DF-1004', name: 'Aarav Mehta', email: 'aarav@dayflow.demo', phone: '+91 98111 22445', department: 'Engineering', role: 'Senior Engineer', employmentType: 'Full-time', joiningDate: '2022-03-08', location: 'Mumbai', status: 'Active', salary: 185000, avatarColor: '#1C9B72' },
  { id: 'e-003', employeeId: 'DF-1005', name: 'Ishita Rao', email: 'ishita@dayflow.demo', phone: '+91 98222 56789', department: 'Sales', role: 'Account Executive', employmentType: 'Full-time', joiningDate: '2024-01-19', location: 'Delhi', status: 'On leave', salary: 110000, avatarColor: '#D58B16' },
  { id: 'e-004', employeeId: 'DF-1006', name: 'Kabir Singh', email: 'kabir@dayflow.demo', phone: '+91 98444 11223', department: 'Engineering', role: 'Mobile Engineer', employmentType: 'Full-time', joiningDate: '2023-09-04', location: 'Pune', status: 'Active', salary: 155000, avatarColor: '#9A65D6' },
  { id: 'e-005', employeeId: 'DF-1007', name: 'Nisha Kapoor', email: 'nisha@dayflow.demo', phone: '+91 98666 77889', department: 'People Ops', role: 'People Partner', employmentType: 'Full-time', joiningDate: '2021-11-22', location: 'Bengaluru', status: 'Active', salary: 135000, avatarColor: '#D24F5A' },
]
