import type { LeaveBalance, LeaveRequest } from '@/types/leave.types'

export const mockLeaveBalances: LeaveBalance[] = [
  { type: 'Annual', remaining: 12, total: 18, color: '#3154D8' },
  { type: 'Sick', remaining: 6, total: 10, color: '#1C9B72' },
  { type: 'Personal', remaining: 3, total: 5, color: '#D58B16' },
]

export const mockLeaves: LeaveRequest[] = [
  { id: 'leave-1', employeeId: 'e-001', employeeName: 'Employee Demo', type: 'Annual', startDate: '2026-09-04', endDate: '2026-09-05', days: 2, reason: 'Family event', status: 'Pending', createdAt: '2026-08-20' },
  { id: 'leave-2', employeeId: 'e-003', employeeName: 'Ishita Rao', type: 'Sick', startDate: '2026-08-22', endDate: '2026-08-22', days: 1, reason: 'Medical appointment', status: 'Approved', createdAt: '2026-08-21' },
  { id: 'leave-3', employeeId: 'e-002', employeeName: 'Aarav Mehta', type: 'Work from home', startDate: '2026-08-26', endDate: '2026-08-26', days: 1, reason: 'Home maintenance', status: 'Rejected', createdAt: '2026-08-19' },
]
