import type { Notification } from '@/types/notification.types'

export const mockNotifications: Notification[] = [
  { id: 'n-1', title: 'Leave request approved', message: 'Your sick leave request for 22 Aug was approved.', type: 'leave', time: '12 min ago', read: false },
  { id: 'n-2', title: 'Time to check in', message: 'Start your day by recording your attendance.', type: 'attendance', time: '1 hr ago', read: false },
  { id: 'n-3', title: 'Salary slip available', message: 'Your August 2026 salary slip is ready to view.', type: 'payroll', time: 'Yesterday', read: true },
  { id: 'n-4', title: 'Welcome to Dayflow', message: 'Your People Operations workspace is ready.', type: 'system', time: '2 days ago', read: true },
]
