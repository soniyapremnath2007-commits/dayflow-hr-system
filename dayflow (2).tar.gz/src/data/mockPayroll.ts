import type { Payroll, SalarySlip } from '@/types/payroll.types'

export const mockPayroll: Payroll[] = [
  { id: 'pay-1', employeeId: 'e-001', month: 'August 2026', gross: 125000, deductions: 14500, net: 110500, status: 'Paid', paidOn: '2026-08-01' },
  { id: 'pay-2', employeeId: 'e-001', month: 'July 2026', gross: 125000, deductions: 14500, net: 110500, status: 'Paid', paidOn: '2026-07-01' },
  { id: 'pay-3', employeeId: 'e-001', month: 'June 2026', gross: 125000, deductions: 14500, net: 110500, status: 'Paid', paidOn: '2026-06-01' },
  { id: 'pay-4', employeeId: 'e-002', month: 'August 2026', gross: 185000, deductions: 22100, net: 162900, status: 'Paid', paidOn: '2026-08-01' },
]

export const createSalarySlip = (payroll: Payroll): SalarySlip => {
  const basic = Math.round(payroll.gross * 0.6)
  const housing = Math.round(payroll.gross * 0.24)
  const providentFund = Math.round(payroll.deductions * 0.62)
  const professionalTax = Math.round(payroll.deductions * 0.17)
  return {
    ...payroll,
    allowances: [
      { label: 'Basic salary', amount: basic },
      { label: 'House rent allowance', amount: housing },
      { label: 'Flexi benefits', amount: payroll.gross - basic - housing },
    ],
    deductionItems: [
      { label: 'Provident fund', amount: providentFund },
      { label: 'Professional tax', amount: professionalTax },
      { label: 'TDS', amount: payroll.deductions - providentFund - professionalTax },
    ],
  }
}

export const mockSalarySlip: SalarySlip = createSalarySlip(mockPayroll[0])
