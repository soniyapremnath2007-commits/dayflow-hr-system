import { ROLES } from '@/constants/roles'
import type { LoginInput, User } from '@/types/auth.types'

export const demoPassword = 'demo123'

export const mockUsers: (User & { password: string })[] = [
  { id: 'u-001', name: 'Employee Demo', email: 'employee@dayflow.demo', password: demoPassword, role: ROLES.EMPLOYEE, employeeId: 'DF-1001', department: 'Product' },
  { id: 'u-002', name: 'HR Demo', email: 'hr@dayflow.demo', password: demoPassword, role: ROLES.HR, employeeId: 'DF-1002', department: 'People Operations' },
  { id: 'u-003', name: 'Admin Demo', email: 'admin@dayflow.demo', password: demoPassword, role: ROLES.ADMIN, employeeId: 'DF-1003', department: 'Operations' },
]

export const findMockUser = ({ email, password }: LoginInput) =>
  mockUsers.find((user) => user.email.toLowerCase() === email.toLowerCase() && user.password === password)
