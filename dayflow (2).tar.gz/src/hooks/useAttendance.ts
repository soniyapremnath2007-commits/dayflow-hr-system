import { useAttendanceStore } from '@/store/attendanceStore'
export const useAttendance = (employeeId?: string) => {
  const state = useAttendanceStore()
  return { ...state, records: employeeId ? state.records.filter((record) => record.employeeId === employeeId) : state.records }
}
