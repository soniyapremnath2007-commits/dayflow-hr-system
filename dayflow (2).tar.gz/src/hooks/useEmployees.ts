import { useEmployeeStore } from '@/store/employeeStore'
export const useEmployees = () => useEmployeeStore()
