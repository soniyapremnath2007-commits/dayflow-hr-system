import { useLeaveStore } from '@/store/leaveStore'
export const useLeave = (employeeId?: string) => {
  const state = useLeaveStore()
  return { ...state, requests: employeeId ? state.requests.filter((request) => request.employeeId === employeeId) : state.requests }
}
