import { useNotificationStore } from '@/store/notificationStore'
export const useNotifications = () => {
  const state = useNotificationStore()
  return { ...state, unreadCount: state.notifications.filter((item) => !item.read).length }
}
