import { usePayrollStore } from '@/store/payrollStore'
export const usePayroll = (employeeId?: string) => {
  const state = usePayrollStore()
  return { ...state, payroll: employeeId ? state.payroll.filter((item) => item.employeeId === employeeId) : state.payroll }
}
