import { create } from 'zustand'
import { mockAttendance, mockCorrections } from '@/data/mockAttendance'
import { todayKey } from '@/utils/date'
import { calculateWorkingHours } from '@/utils/attendance'
import type { Attendance, AttendanceCorrection } from '@/types/attendance.types'

const timeNow = () => {
  const now = new Date()
  return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`
}

interface AttendanceState {
  records: Attendance[]
  corrections: AttendanceCorrection[]
  checkIn: (employeeId: string) => void
  checkOut: (employeeId: string) => void
  requestCorrection: (correction: AttendanceCorrection) => void
  updateCorrection: (id: string, status: AttendanceCorrection['status']) => void
}

export const useAttendanceStore = create<AttendanceState>((set) => ({
  records: mockAttendance,
  corrections: mockCorrections,
  checkIn: (employeeId) => set((state) => {
    const existing = state.records.find((record) => record.employeeId === employeeId && record.date === todayKey())
    if (existing) return { records: state.records.map((record) => record.id === existing.id ? { ...record, checkIn: timeNow(), status: 'Present' } : record) }
    return { records: [{ id: `att-${Date.now()}`, employeeId, date: todayKey(), checkIn: timeNow(), status: 'Present', workHours: 0 }, ...state.records] }
  }),
  checkOut: (employeeId) => set((state) => {
    const existing = state.records.find((record) => record.employeeId === employeeId && record.date === todayKey())
    if (!existing) return state
    const checkOut = timeNow()
    return { records: state.records.map((record) => record.id === existing.id ? { ...record, checkOut, workHours: calculateWorkingHours(record.checkIn, checkOut) } : record) }
  }),
  requestCorrection: (correction) => set((state) => ({ corrections: [correction, ...state.corrections] })),
  updateCorrection: (id, status) => set((state) => ({ corrections: state.corrections.map((item) => item.id === id ? { ...item, status } : item) })),
}))
