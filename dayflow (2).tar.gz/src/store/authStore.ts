import AsyncStorage from '@react-native-async-storage/async-storage'
import { create } from 'zustand'
import { createJSONStorage, persist } from 'zustand/middleware'
import { findMockUser } from '@/data/mockUsers'
import type { LoginInput, User } from '@/types/auth.types'
import type { Role } from '@/constants/roles'

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  role: Role | null
  loading: boolean
  error: string | null
  login: (input: LoginInput) => Promise<User | null>
  logout: () => void
  clearError: () => void
}

export const useAuthStore = create<AuthState>()(persist((set) => ({
  user: null,
  isAuthenticated: false,
  role: null,
  loading: false,
  error: null,
  login: async (input) => {
    set({ loading: true, error: null })
    const match = findMockUser(input)
    if (!match) {
      set({ loading: false, error: 'We could not match those demo credentials.' })
      return null
    }
    const { password: _password, ...user } = match
    set({ user, isAuthenticated: true, role: user.role, loading: false })
    return user
  },
  logout: () => set({ user: null, isAuthenticated: false, role: null, error: null }),
  clearError: () => set({ error: null }),
}), { name: 'dayflow-auth', storage: createJSONStorage(() => AsyncStorage) }))
