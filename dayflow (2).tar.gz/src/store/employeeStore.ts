import { create } from 'zustand'
import { mockEmployees } from '@/data/mockEmployees'
import type { Employee } from '@/types/employee.types'

interface EmployeeState {
  employees: Employee[]
  selectedEmployee: Employee | null
  selectEmployee: (employee: Employee | null) => void
  addEmployee: (employee: Employee) => void
  updateEmployee: (id: string, patch: Partial<Employee>) => void
}

export const useEmployeeStore = create<EmployeeState>((set) => ({
  employees: mockEmployees,
  selectedEmployee: null,
  selectEmployee: (selectedEmployee) => set({ selectedEmployee }),
  addEmployee: (employee) => set((state) => ({ employees: [employee, ...state.employees] })),
  updateEmployee: (id, patch) => set((state) => ({ employees: state.employees.map((employee) => employee.id === id ? { ...employee, ...patch } : employee) })),
}))
