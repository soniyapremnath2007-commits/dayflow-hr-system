import { create } from 'zustand'
import { mockLeaveBalances, mockLeaves } from '@/data/mockLeaves'
import type { LeaveBalance, LeaveRequest, LeaveStatus } from '@/types/leave.types'

interface LeaveState {
  requests: LeaveRequest[]
  balances: LeaveBalance[]
  applyLeave: (request: LeaveRequest) => void
  updateStatus: (id: string, status: LeaveStatus) => void
}

export const useLeaveStore = create<LeaveState>((set) => ({
  requests: mockLeaves,
  balances: mockLeaveBalances,
  applyLeave: (request) => set((state) => ({ requests: [request, ...state.requests] })),
  updateStatus: (id, status) => set((state) => ({ requests: state.requests.map((request) => request.id === id ? { ...request, status } : request) })),
}))
