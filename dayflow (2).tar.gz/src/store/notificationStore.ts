import { create } from 'zustand'
import { mockNotifications } from '@/data/mockNotifications'
import type { Notification } from '@/types/notification.types'

interface NotificationState { notifications: Notification[]; markRead: (id: string) => void; markAllRead: () => void }
export const useNotificationStore = create<NotificationState>((set) => ({
  notifications: mockNotifications,
  markRead: (id) => set((state) => ({ notifications: state.notifications.map((item) => item.id === id ? { ...item, read: true } : item) })),
  markAllRead: () => set((state) => ({ notifications: state.notifications.map((item) => ({ ...item, read: true })) })),
}))
