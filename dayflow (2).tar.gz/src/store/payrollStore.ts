import { create } from 'zustand'
import { mockPayroll, mockSalarySlip } from '@/data/mockPayroll'
import type { Payroll, SalarySlip } from '@/types/payroll.types'

interface PayrollState { payroll: Payroll[]; salarySlip: SalarySlip }
export const usePayrollStore = create<PayrollState>(() => ({ payroll: mockPayroll, salarySlip: mockSalarySlip }))
