import type { ViewStyle } from 'react-native'

export const shadows: Record<string, ViewStyle> = {
  card: { shadowColor: '#1B2A55', shadowOpacity: 0.07, shadowRadius: 16, shadowOffset: { width: 0, height: 6 }, elevation: 3 },
  floating: { shadowColor: '#3154D8', shadowOpacity: 0.2, shadowRadius: 14, shadowOffset: { width: 0, height: 7 }, elevation: 6 },
}
