export type AttendanceStatus = 'Present' | 'Absent' | 'Late' | 'On leave' | 'Half day'

export interface Attendance {
  id: string
  employeeId: string
  date: string
  checkIn?: string
  checkOut?: string
  status: AttendanceStatus
  workHours: number
  note?: string
}

export interface AttendanceCorrection {
  id: string
  attendanceId: string
  employeeId: string
  date: string
  requestedCheckIn: string
  requestedCheckOut: string
  reason: string
  status: 'Pending' | 'Approved' | 'Rejected'
}
