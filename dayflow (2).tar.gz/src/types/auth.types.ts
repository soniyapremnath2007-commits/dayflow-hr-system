import type { Role } from '@/constants/roles'

export interface User {
  id: string
  name: string
  email: string
  role: Role
  employeeId: string
  department: string
  avatar?: string
}

export interface LoginInput {
  email: string
  password: string
}
