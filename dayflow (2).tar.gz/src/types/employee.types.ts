export interface Department {
  id: string
  name: string
  headcount: number
  color: string
}

export interface Employee {
  id: string
  employeeId: string
  name: string
  email: string
  phone: string
  department: string
  role: string
  employmentType: 'Full-time' | 'Part-time' | 'Contract'
  joiningDate: string
  location: string
  status: 'Active' | 'On leave' | 'Inactive'
  salary: number
  avatarColor: string
}
