export type LeaveType = 'Annual' | 'Sick' | 'Personal' | 'Work from home'
export type LeaveStatus = 'Pending' | 'Approved' | 'Rejected' | 'Cancelled'

export interface LeaveBalance {
  type: LeaveType
  remaining: number
  total: number
  color: string
}

export interface LeaveRequest {
  id: string
  employeeId: string
  employeeName: string
  type: LeaveType
  startDate: string
  endDate: string
  days: number
  reason: string
  status: LeaveStatus
  createdAt: string
}
