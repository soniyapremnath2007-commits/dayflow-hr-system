export type NotificationType = 'leave' | 'attendance' | 'payroll' | 'system'

export interface Notification {
  id: string
  title: string
  message: string
  type: NotificationType
  time: string
  read: boolean
}
