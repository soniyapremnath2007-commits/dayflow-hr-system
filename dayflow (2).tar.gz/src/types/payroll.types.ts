export interface Payroll {
  id: string
  employeeId: string
  month: string
  gross: number
  deductions: number
  net: number
  status: 'Paid' | 'Processing' | 'Pending'
  paidOn?: string
}

export interface SalarySlip extends Payroll {
  allowances: { label: string; amount: number }[]
  deductionItems: { label: string; amount: number }[]
}
