export interface Report {
  id: string
  title: string
  description: string
  period: string
  value: string
  trend: number
}
