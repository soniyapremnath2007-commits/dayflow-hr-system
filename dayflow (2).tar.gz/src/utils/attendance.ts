export const calculateWorkingHours = (checkIn?: string, checkOut?: string) => {
  if (!checkIn || !checkOut) return 0
  const [inHour, inMinute] = checkIn.split(':').map(Number)
  const [outHour, outMinute] = checkOut.split(':').map(Number)
  return Math.max(0, Number(((outHour * 60 + outMinute - inHour * 60 - inMinute) / 60).toFixed(1)))
}

export const attendancePercentage = (present: number, total: number) => (total ? Math.round((present / total) * 100) : 0)
