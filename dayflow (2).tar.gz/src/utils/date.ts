export const formatDate = (value: string, options?: Intl.DateTimeFormatOptions) =>
  new Intl.DateTimeFormat('en-IN', options ?? { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(`${value}T00:00:00`))

export const todayKey = () => new Date().toISOString().slice(0, 10)

export const formatTime = (value = new Date()) =>
  new Intl.DateTimeFormat('en-IN', { hour: 'numeric', minute: '2-digit' }).format(value)
