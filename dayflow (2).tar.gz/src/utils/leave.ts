export const calculateLeaveDuration = (startDate: string, endDate: string) => {
  const start = new Date(`${startDate}T00:00:00`).getTime()
  const end = new Date(`${endDate}T00:00:00`).getTime()
  return Math.max(0, Math.floor((end - start) / 86400000) + 1)
}
