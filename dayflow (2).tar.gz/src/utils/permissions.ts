import { HR_ROLES } from '@/constants/roles'
import type { Role } from '@/constants/roles'

export const canAccessHR = (role?: Role | null) => Boolean(role && HR_ROLES.includes(role))
export const canManageEmployees = (role?: Role | null) => role === 'ADMIN' || role === 'HR'
export const canApproveRequests = (role?: Role | null) => canAccessHR(role)
