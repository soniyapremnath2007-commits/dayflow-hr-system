import { z } from 'zod'

export const attendanceCorrectionSchema = z.object({
  date: z.string().min(1, 'Date is required'),
  checkIn: z.string().regex(/^\d{2}:\d{2}$/, 'Use HH:MM'),
  checkOut: z.string().regex(/^\d{2}:\d{2}$/, 'Use HH:MM'),
  reason: z.string().trim().min(5, 'Add a reason'),
})
