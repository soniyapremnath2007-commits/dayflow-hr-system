import { z } from 'zod'

export const loginSchema = z.object({ email: z.string().trim().email('Enter a valid email'), password: z.string().min(6, 'Use at least 6 characters') })
export const registerSchema = loginSchema.extend({ name: z.string().trim().min(2, 'Name is required'), employeeId: z.string().trim().min(3, 'Employee ID is required') })
export const forgotPasswordSchema = z.object({ email: z.string().trim().email('Enter a valid email') })
export const resetPasswordSchema = z.object({ password: z.string().min(6, 'Use at least 6 characters'), confirmPassword: z.string().min(6, 'Confirm your password') }).refine((data) => data.password === data.confirmPassword, { path: ['confirmPassword'], message: 'Passwords do not match' })
export type LoginFormValues = z.infer<typeof loginSchema>
export type ResetPasswordFormValues = z.infer<typeof resetPasswordSchema>
