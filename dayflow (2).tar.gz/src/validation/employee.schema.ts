import { z } from 'zod'

export const employeeSchema = z.object({
  name: z.string().trim().min(2, 'Name is required'),
  email: z.string().trim().email('Enter a valid email'),
  employeeId: z.string().trim().regex(/^DF-\d{4}$/, 'Use format DF-0000'),
  department: z.string().trim().min(2, 'Department is required'),
  role: z.string().trim().min(2, 'Role is required'),
  salary: z.coerce.number().positive('Salary must be positive'),
})
export type EmployeeFormValues = z.infer<typeof employeeSchema>
