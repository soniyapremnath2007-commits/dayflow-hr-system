import { z } from 'zod'

export const leaveSchema = z.object({
  type: z.enum(['Annual', 'Sick', 'Personal', 'Work from home']),
  startDate: z.string().min(1, 'Start date is required'),
  endDate: z.string().min(1, 'End date is required'),
  reason: z.string().trim().min(5, 'Add a short reason'),
}).refine((data) => data.endDate >= data.startDate, { path: ['endDate'], message: 'End date must be after start date' })
export type LeaveFormValues = z.infer<typeof leaveSchema>
