import { z } from 'zod'

export const payrollSchema = z.object({ gross: z.coerce.number().positive(), deductions: z.coerce.number().nonnegative() })
